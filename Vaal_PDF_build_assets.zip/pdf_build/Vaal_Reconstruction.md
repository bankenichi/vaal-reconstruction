# The Vaal Tongue: A Reconstruction

*A reverse-engineering of multiple constructed-language ("Vaal") texts from Path of Exile / Path of Exile 2, read as a Mesoamerican creole built on attested Maya and Nahuatl roots.*

---

## 1. Overview

This document consolidates the full reconstruction of multiple written Vaal texts: the **Atziri Chant** (sung in Utzaal on the eve of the Cataclysm; §3), the **Cuachic Vault Litany** (the call-and-response of Blood Priestess Zelina and Blood Priest Zolin in PoE2 0.5.0; §4), the **Commander's Temple barks** (Elite Commander, in Atziri's Temple at Lira Vaal; §5), **The Drill Sergeant & the Vaal Regiment** (Drill Sergeant, in Atziri's Temple at Lira Vaal; §6), and **Stray captures** (Kamasan Smith, in Atziri's Temple at Lira Vaal; §7). Each is given as a Vaal original with an English translation, followed by a single combined lexicon of every token (§8), an appendix of recorded alternates and open questions (§9), the supporting lore (§10), the working method (§12), and status (§13), as well as citations (§14).

The first three are **offerings flowing upward to Atziri**, the worshippers give themselves (blood, flesh, spirit, heart, their dead, their "new children") and the queen receives and consumes. Directionality is uniform across all of them.

---

## 2. Linguistic framework

### 2.1 The standard

Every reading rests on an **attested dictionary root** with workable phonology. No hallucinated grammar; no "squinting until it fits." Where a root cannot be verified, the token is flagged and its candidates are preserved as alternates rather than promoted to a committed reading.

### 2.2 The source palette: a three-language creole

The conlang is not built from one language but three, plus Romance (Spanish) loans:

| Layer | Role | Evidence |
|---|---|---|
| **Yucatec Maya** | Core, most content roots, the article *le*, presentatives, blood/spirit/flesh vocabulary | *ik'*, *ba'*, *le*, *kuxtal*, *kíimil*, *iitz*, *il* |
| **Classical Nahuatl** | Layer, divinity, place-names, negation, several adjectives | *teōtl*, *-tlān*, *aocmo*, *cualli*, *nochi*, *yancuic*, *yocoya* |
| **Highland Maya (K'iche')** | Thin seam, surfaces only where the other two cannot account for a sound | *jare* (the /r/) |
| **Romance (Spanish)** | Loans, abstract/martial concepts | *ascensión* + *-ada*; *jefe* → *xefe*; *otra* → *u'tra*; *échelo*; *daca*; *fulgor* → *fukuur* (soft) |

**The "alien" letters were the clues.** Three sounds do not belong to the Yucatec-plus-Nahuatl core, and each turned out to mark a different source:

- **/g/** in *Gyan'uks* → Nahuatl *yancuic* "new." Nahuatl has no native /g/; the spelling is a stylization.[15]
- **/r/** in *jare* → Highland Maya. Yucatec shifted proto-Mayan \*r to /j/ and Nahuatl never had /r/, but **K'iche' keeps it**, its core definite articles are *we / le / ri* ("this / that / the"). An /r/ in this text points squarely at K'iche'an.[17]
- **/f/** in *fukuur* → Spanish. No Mayan or Nahuatl word carries /f/ (in Yucatec, *d f g j r v* occur only in loans), so the /f/ marks a Romance loan, most likely *fulgor* "blaze, lightning-flash" (see Text 3, §5, and §9.4).[9,15]
- **/d/** in *daka* → Spanish, by the same logic, and checked against all three source languages, not just two. A voiced stop /d/ is loan-only in Yucatec Maya, Classical Nahuatl, **and K'iche'**; none has it natively. K'iche' is the test that matters, since it was K'iche' that supplied the /r/ in *jare*, but even there the only non-plain stop is the implosive /ɓ/ (written *b'*, a *b*-sound, not *d*), and the one genuinely odd consonant, a dialectal [ð], is an intervocalic allophone of /l/, not a word-initial /d/ stop. So a /d/-initial root cannot be native to the palette; in a line already carrying Spanish loans (*xefe*, *u'tra*), it points to *daca* "give it here" (see §9.4).[9,15,17,18]

### 2.3 A diagnostic key for unfamiliar sounds

The lesson of /r/ is that an "alien" sound is not automatically a loan: /r/ looked foreign but was K'iche', inside the palette, just a different layer. So a not-yet-listed sound splits into two predictive classes. These are heuristics for parsing future tokens, to be tested against new text rather than treated as law (the spelling is the game's stylization, not IPA).

**Points to a specific layer *inside* the palette:**

| Sound (spelling) | Points to | Why |
|---|---|---|
| ejective / glottalized *p' t' k' q' ts' ch'*, or implosive /ɓ/ (*b, b'*) | **Maya** (Yucatec or K'iche') | Nahuatl has no glottalized consonants |
| /tɬ/ (*tl*), /kʷ/ (*cu, uc*) | **Nahuatl** | neither Maya language has them, cf. *tlayeb*, *atla*, the *cua-* of *Cuachic* |
| /r/ (tap), uvular /q/ ~ /q'/ | **K'iche' / Highland Maya** | Yucatec lost \*r→j and has no uvulars; Nahuatl has neither. /r/ cracked *jare*; a true *q* (≠ *k*) would be the next such tell, as yet unseen |
| lexical tone / acute-marked vowels (*í, á*) | **Yucatec** (soft) | tone is Yucatec, not Nahuatl or (mostly) K'iche', cf. *kíimil*, *náach* |

**Points *outside* the palette (loan, in practice Spanish):**

| Sound (spelling) | Call | Caveat |
|---|---|---|
| /d/, /f/ | Spanish loan | established (*daka*, *fukuur*); /f/ (and /v/) *could* be a Nahuatl /w/→[v~f] allophone, so rule out a *w*-word first |
| /v/, /z/, /ʒ/, /dʒ/, /θ/, /ɲ/ (*ñ*), trilled /rr/ | loan, almost certainly Spanish | none is native to any of the three |
| /g/ | **ambiguous → often Nahuatl** | not native anywhere, but recurrently a stylized spelling of Nahuatl. In *Gyan'uks* it spells *yancuic*; and, the cleaner, reusable rule, **word-initial *Gua- / Gue-* = Nahuatl *cua- / cui-* /kʷ/** (the Spanish treatment of /kʷ/, as in *Cuauhtémoc* → *Guatemoc*), so a *G-* before a back vowel flags a hidden Nahuatl /kʷ/ root: *Guatelitzi* ← *cuauh-* "tree" (§9.8), exactly as *Guatemala* ← *Cuauhtēmallān*. Read the rest of the word before deciding |
| plain voiced [b] (non-implosive) | weak flag | *⟨b⟩* normally spells the native implosive /ɓ/; only a clearly plain, voiced [b] in loan context points out |

So the reliable "look outside immediately" set is narrow: **/d/, /f/, /v/, /z/, /ʒ/, /dʒ/, /θ/, /ñ/, and a trilled /rr/.** Everything else either belongs to one of the three layers or (like /g/ and ⟨b⟩) is ambiguous enough to check first.

---

## 3. Text 1: The Atziri Chant[4]

*Sung by Atziri's followers in Utzaal on the eve of the Cataclysm. An exhortation and offering TO Atziri: the blood flows up to her; she is the recipient.*

### The chant

| # | Vaal | English |
|---|---|---|
| 1 | Atziri, Atziri, ek te mucane Vaal! | Atziri, Atziri, star of the mighty Vaal! |
| 2 | Teoyuxtlane ascensionada! Teoyuxtlane Yutsal! | Divine, ascended; divine Utzaal! |
| 3 | Atziri, Atziri, ma kilya Zerphi! | Atziri, Atziri, undying as Zerphi! |
| 4 | Ti itsok anab nochira! Kextal xi kujkuali ik'bala! | To you, the blood of all your servants; transform us, make our spirit worthy! |
| 5 | Atziri, Atziri, ikba'yucane Vaal! | Atziri, Atziri, undying breath of the Vaal! |
| 6 | A'te 'Ibil tlayeb kutsen! A'te ik'el tlayeb kifba! | Here, our flesh laid bare in the dark, the offering; here, our hidden self in the dark, the heart! |
| 7 | Atziri, Atziri, ascenada akal! | Atziri, Atziri, risen into the eternal waters! |
| 8 | Aiokmo til xu'te! Aiokmo tul jare elba! | No more burning to ash, no ending; no more dwindling to embers, no going out! |

### Line notes

- **Lines 3 & 5** both render *undying* (*kilya*, then *ikba'yucane*). The repetition is deliberate: an immortality motif, fitting a queen who sought eternal life.
- **Dramatic irony runs throughout.** "Eternal waters" (*akal*) is the still pond of the nightmare realm she ends up trapped in. "No more burning… no going out" is sung on the very night the Cataclysm burns Utzaal to nothing. "Undying as Zerphi," though Zerphi did, in the end, die; he is undying only in legend.
- **Source-validated against the game files.** The chant exists verbatim in the datamined `NPCTextAudio` table as `VaalSermon_01`–`08`, in order, with zero drift. The internal name *VaalSermon* confirms the register, and the data fixes the canonical spelling *A'te 'Ibil* (an earlier draft wrote *Íbil*).

---

## 4. Text 2: The Cuachic Vault Litany[2,3]

*Call by Blood Priestess Zelina; response by Blood Priest Zolin. The sealed-away Vaal survivors offering THEMSELVES up to Atziri, the same upward direction as the chant above, preserved as liturgy from the height of her power. In the game files each boss carries eight chant lines tagged ChantA–ChantH; the two columns below are those two pools, aligned by their shared A–H index.*

### The litany

| Pair | Speaker | Vaal | English |
|---|---|---|---|
| 1 | Zelina (call) | Kuxte' kíimil'! | Life and death! |
| 1 | Zolin (response) | Tlaxye' le Vaal! | The people of the Vaal! |
| 2 | Zelina (call) | Ma'oxe ik'el! | The countless spirits! |
| 2 | Zolin (response) | Atziri le'itzil! | Atziri, the essence! |
| 3 | Zelina (call) | Xatlene kujkuali! | Kindle the worthy! |
| 3 | Zolin (response) | Gyan'uks ko'janti! | Your new children, come, devour! |
| 4 | Zelina (call) | A'te 'Ibil! | Behold the flesh! |
| 4 | Zolin (response) | A'te ik'el! | Behold the spirit! |
| 5 | Zelina (call) | Yaxe chikula'! | The first sign! |
| 5 | Zolin (response) | Tzokan'te ik'el! | The last spirit! |
| 6 | Zelina (call) | A'te líimek! | Behold those in the earth! |
| 6 | Zolin (response) | Yatle yutsal! | There stands Utzaal! |
| 7 | Zelina (call) | Tlayeb kutsen! | In the dark, the offering! |
| 7 | Zolin (response) | Tlayeb kifba! | In the dark, the heart! |
| 8 | Zelina (call) | U'Te kuxkal! | Behold the living! |
| 8 | Zolin (response) | A'te yuquia! | Behold the made! |

### Line notes

- **Pair 2** is the multitude and the one: *Ma'oxe ik'el* "the countless spirits" (numberless faithful offered up) answered by *Atziri le'itzil* "Atziri, the essence": the queen who is the essence they all feed.
- **Pair 3** *Gyan'uks ko'janti* "your new children, come, devour" is metaphorical: the latter-day vault Vaal as Atziri's "new children," offered for her to consume. Not literal children.
- **Pair 6** *A'te líimek* / *Yatle yutsal* sets the buried dead against the standing city: those in the earth, and Utzaal still rising.
- **Source-validated against the game files.** All sixteen lines match poe2db's extracted audio subtitles exactly, with zero transcription drift. Zelina's call pool is tagged *BloodPriestess_ChantA–H* (*Kuxte' kíimil'* … *U'Te kuxkal*); Zolin's response pool *BloodPriest_ChantA–H* (*Tlaxye' le Vaal* … *A'te yuquia*). This independently confirms the *Ma'oxe* reading: it appears verbatim as *Ma'oxe ik'el*. Both bosses sit at *Metadata/Monsters/VaalMonsters/Living/BloodPriests/*: "Living" Vaal, i.e. present-day descendants, which fits their being recruited as hideout vendors once subdued.

---

## 5. Text 3: Quemalani, the Elite Commander[1]

*The Vaal voice-lines of the **Commander** boss in the Commander's Chamber of **Atziri's Temple at Lira Vaal** (PoE2's Fate of the Vaal). The encounter shows up under variant names, **Quemalani, the Elite Commander** (live chat feed) and **Xolotl, the Royal Commander** (the poe2db datamine page; internal asset **BlackjawPastLiving**), but it is one and the same boss and voice pool, and the particular label is not significant. The Commander is **fire-based**: it breathes fire, which squares with its blaze imagery: the Vaal line *A'te fukuur!* "Behold the blaze!" and the English bark "Flaming Glory!" (This temple is **not** the Temple of Atzoatl; that was the PoE1 Incursion temple, raided ~20 years earlier by the Exile/"Godslayer"; the PoE2 temple reuses its room-names and grid, and the Vaal mistake the player for that earlier "demon of Atzoatl.")*

**These are separate barks, not one speech.** The lines below are independent voice-line phrases the Commander fires at different points in the fight: in the chat feed they appear interleaved with one another and with English barks ("Flaming Glory!", "No further!"), not as a continuous oration. Each is rendered on its own; the token readings stand, but there is no connective narrative tying them into a single address.

**Orthography note.** Two spelling conventions are clear from the in-game audio: **j = /h/** (so *ja* = *ha'* "water"; *mujuk'* = /muhuk'/) and **x = /ʃ/** ("sh"). This also explains *xefe*: it is the **archaic Spanish spelling of *jefe*** (old Spanish *x* = /ʃ/). The "alien" letters stay source-clues: **/g/** → Nahuatl (*yancuic*), **/r/** → K'iche' (Highland Maya), and **/f/** & **/d/** → Spanish (both are loan-only across Maya, Nahuatl, and K'iche'); see *fukuur* and *daka* in §9.4.

### The barks (independent voice-lines)

| Group | Vaal | English |
|---|---|---|
| Short cry | Eche lu nochbe! | Pour it out, all that we are! |
| Short cry | Kí' inib! | Sweet, my flesh! |
| Bark 1 | 'Ayok ta' en, u mujuk' le mucane, niáach i'chian. | Nothing more for me now; the strength of the mighty is in me, deep within her house. |
| Bark 1 | A'te waja yatle u'tra buxa! | Behold the offering; there stands another! |
| Bark 1 | A'te fukuur! | Behold the blaze! |
| Bark 2 | Xi daka puxe… | Bring the draught… |
| Bark 2 | 'Ayok kifba Atziri kilya sakilja. | The heart beats no more; for Atziri, the undying, the white drink. |
| Bark 2 | Ik'eche sakilja atla donuks. | You are the breath within it, the sacred water, our draught. |
| Bark 2 | Donuks… ko'soxsal. | Drink… raw and fresh! |
| Bark 2 | Donuks… ko'mujuk! | Drink… and take strength! |
| Bark 3 | Xi u'te cha'tsoke, a'te itsok xefe yotlapek le le Vaal te'moxti qexcan… | See, the end comes round again; behold the blood. Commander of the Vaal altar, where all are remade… |
| Bark 3 | Na' puyao. | the reddened offering. |
| Bark 3 | Ich tlapec u'te puyao, a'te itsok pu uch' ta'nuk! | On the altar, watch it redden; behold the blood; drink deep, great one! |

*Register note: the speaker is a military high leader, not a priest. The lines read as a commander's orders and declarations; he leads the sacrifice rather than presiding over it. "We drink" is a war-band's blood-draught before battle (he drinks first, then commands his men); "my flesh, and gladly" is a leader offering his own body first.*

### Line notes

- **xefe = Spanish *jefe* "chief, commander"**: a Romance loan beside *ascensión*, and a self-naming one: the line names the speaker's own office. The Romance seam is a confirmed pattern, not a one-off.
- **The blood-draught is sourced ritual.** *uch'* is Yucatec *uk'* "to drink" (*ba'ax taak a uk'ul?* "what do you want to drink?"). *sakilja* is *sak ha'* "white water," an attested Maya **ceremonial** drink, and inscriptions record *sak juy ch'ich'* "white stirred blood," a beverage built on the blood metaphor. So *sakilja + itsok + uch'* is one coherent, sourced image: the sacred white draught that is blood, drunk at the altar.

*(Text 3's tokens are folded into the combined lexicon, §8; its soft parses and open items into the appendix, §9.4 and §9.7.)*

---

## 6. Text 4: The Drill Sergeant & the Vaal Regiment[1]

*Captured live from in-game global chat (not yet in the datamined pool). A **call-and-response drill** between a **Drill Sergeant** and the **Vaal Regiment**, the military cousin of the Cuachic Vault litany (§4): a fixed call met by a fixed war-cry. The sergeant's name randomizes across instances (**Tizoc**, **Cotan**, **Axilo**), the same variant-name device seen with the Commander (Quemalani, Xolotl); all are Nahuatl-style officer names. Only the green NPC lines are Vaal; the player-character's English banter and "Error:" UI lines are excluded. The fuller catechism below, with its second response *Atziri!*, was filled in from additional information provided by *Substantial_Bat_8440*; an earlier capture had only the opening and the variant calls.*

### The drill

*A call-and-response catechism. The sergeant calls; the regiment answers with one of two shouts, the war-cry U'te mucane! "Behold, the mighty!" or the queen's name, Atziri! The sergeant's name varies per instance (Tizoc, Cotan, Axilo); the lines do not.*

| Speaker | Vaal | English |
|---|---|---|
| Sergeant | Otsuks! Tzokan'te u'te ik'el… | Company! Behold the last spirit… |
| Regiment | Atziri! | Atziri! |
| Sergeant | A'te Kuxkal tlayeb kutsen. Ela tlayeb ukto! Máax ka ti a'tul? | Behold the living, the offering in the dark. The dark [ukto] burns! Who goes there? |
| Regiment | Atziri! | Atziri! |
| Sergeant | Otsuks! Máax ka ti a'tul? | Company! Who goes there? |
| Regiment | U'te mucane! | Behold, the mighty! |
| Sergeant | Máax ka ti cheyel? | Who are you to stand watch here? |
| Regiment | U'te mucane! | Behold, the mighty! |
| Sergeant | Máax tlayeb mucane? | Who is the mighty of the dark? |
| Regiment | Atziri! | Atziri! |

*Other one-off sergeant calls, captured outside the catechism sequence:*

| Vaal | English |
|---|---|
| Otsuks, quxzeh! | Company, bite! Be fierce! |
| Axba!? Kíibsa' ta' en! | What!? Kill, before me! |

### Line notes

- **A call-and-response catechism.** The sergeant calls; the regiment answers with either the war-cry *U'te mucane!* "Behold, the mighty!" or the queen's name *Atziri!* It is the military cousin of the Cuachic Vault litany (§4), a fixed liturgy in a drill register.
- **Otsuks** "Company! Fall in!": Nahuatl presentative *o* "behold!"[34] + Yucatec *tsuk* "cluster, company"[31][36]; the fixed opener, with only the *-s* coda unresolved.
- **The catechism runs on committed vocabulary.** *Tzokan'te u'te ik'el* "behold the last spirit" (cf. Text 2's *Tzokan'te ik'el* "the last spirit"); *A'te Kuxkal tlayeb kutsen* "behold the living, the offering in the dark" (the same frame as Text 3's *A'te 'Ibil tlayeb kutsen*); *Máax tlayeb mucane?* "who is the mighty of the dark?", answered *Atziri!* All of *Máax, ti, U'te / A'te, ik'el, Kuxkal, tlayeb, kutsen, mucane, Tzokan'te* are in §8.
- **Ela** = Maya *el / elel* "to burn, blaze" (the root of the committed *elba* "burn out"), with the regular *el → ela* stylization; now in §8. **ukto** is the one unidentified token: it sits in the offering-slot parallel to *kutsen*, so it reads as a noun ("the dark [offering]"), but no dictionary gives a clean root, so it is left open (§9.7).
- The soft tokens (*a'tul* = Set A *a-* "you" + *taal* "come"; *cheyel* = Nah. *chiya* "to watch/wait" + *-el*; *Axba* = *ba'ax* "what" by metathesis; *quxzeh* = *k'ux* "bite/be fierce"; *Kíibsa'* = *kíim* "die" + causative; plus *ka* and *ta'*) are analysed token-by-token in §9.9; none was promoted to §8 until the closure pass (§9.11), which moved *quxzeh*'s root *k'ux* across.
- One further line, cut off at a screenshot edge, ends "*…ta' nuk!*"; *ta'nuk* "great one" is in §8, but the full line isn't legible and is left unrecorded.

---

## 7. Text 5: Stray captures

*A log of single Vaal lines caught in footage that do not yet form a text of their own. Each is parsed against the committed lexicon; any new root it establishes is folded into §8.*

### Line 1: Xomatl, the Kamasan Smith[37]

*A fire-and-forge boss in Atziri's Temple at Lira Vaal, encountered at the height of Vaal power, before Atziri's communion with the Beast and with no knowledge of the coming Cataclysm. He works at the forge (molten metal, heat, hammer-strikes) until the player enters the room, then speaks this line and attacks.*

| Vaal | English |
|---|---|
| Ti ek tala jare'yantul! | To the star you come; and so, your waning! |

**Line notes**

- Every token is committed vocabulary: *Ti* "to / for," *ek* "star" (Atziri, as hailed in Text 1; the shadow sense "dark" also rides this root), *tala* = *taal* "to come," *jare'* "and so," *yan* "there is / here stands," *tul* "decline, wane" (§8, the same Text 1 sense).
- It is a threat, not Vaal foreboding. The smith is not lamenting the empire's fall, he has no knowledge of the Cataclysm and stands at the height of Vaal power; he is promising the *intruder's* end. The player has come into the star's domain (Atziri's temple), and the smith answers, *jare' yan tul* "and so, your waning," turning from the forge to fight. The line reads literally "and so there is the waning"; the "your" is supplied from context, the doom is aimed at the one who has just come.
- *jare'* here is the **apostrophe form** the lexicon had flagged as undocumented (§9.2); this capture attests it in-game.
- The one soft point is syntax, not vocabulary: *jare'yantul* is written solid but reads as *jare' + yan + tul*. The words are committed; the clause-internal order is provisional.

---

### Line 2: Ahuatotli, the Blind[44]

*A Vaal boss (the Delve boss "Ahuatotli, the Blind"). The shouts are Nahuatl-flavoured ability-cries more than sentences, so most tokens stay soft, but each is given a candidate root below rather than left unparsed.*

| When | Vaal | Token-by-token (candidate roots, soft) |
|---|---|---|
| start | tatlat Atziri | *tatlat*: Nah. *tlatla* "to burn" (redup./stylised) or *tlahtoa* "to speak, proclaim"[10]; *Atziri* (committed) |
| start | Vaal a xomaplat | *Vaal* (committed); *a*: poss. Maya Set A *a-* "your"[7]; *xoma-*: cf. the name *Xomatl* (Text 5); *-plat*: poss. Nah. *tlapal-* "colour, strength"[10]; open |
| start | xictep cutlotl | *xi-*: Nah. imperative "do!"[10]; *-tep*: poss. Nah. *tepē-* "hill" / locative *-tepec*[10]; *cutlotl*: a Nah. *-tl* noun, poss. *cuitlatl* "residue"[10]; open |
| during | azcado | poss. Nah. *āzcatl* "ant"[10]; the *-do* /d/ would mark a Spanish overlay; open |
| during | huatat | poss. Nah. *cuauh-* "tree, eagle" (*hua-* ← *cua-*)[10] + redup. *-tat*; open |
| during | quiquate | poss. Nah. *qui-* (3sg object) + *cua* "to eat" (redup.) → "devours it"[10]; open |
| during | zahua moti | *zahua*: Nah. *zāhua* "to fast" or *zāhuatl* "pox, scab"[10]; *moti*: *mo-* reflexive + open |

### Line 3: Mektul[44]

*A Vaal boss. Unlike Ahuatotli's, several of Mektul's shouts carry recognisable Yucatec roots, fire, wind, gold, and a request-verb, though the full phrases stay soft.*

| When | Vaal | Token-by-token (candidate roots) |
|---|---|---|
| during | táak'iin | *táak'in* "gold, money" (Yucatec)[36], attested |
| during | kahk-tche | *kahk* = *k'áak'* "fire" + *tche* = *che'* "tree, wood"[7][36], both now committed in §8 → "fire-wood, firebrand"; closed |
| during | ka'tse-ik | *ka'* "two, again"[36] + *tse* (open) + *ik* = *ik'* "wind, spirit"[7]; soft |
| during | ipkaat | *-kaat* = *k'áat* "to ask, want"[36]; *ip-* open |
| during | koriek | the *r* marks the K'iche' seam (cf. *jare*, §9.2); re-cut past *kor-*: leading candidate *ko-* "strong, hard" + inchoative *-(i)rik* (cf. *kowirik* "to become strong")[47], a "harden / grow strong" cry; soft, see §9.11 |
| during | xecwa | *-wa*: poss. *waaj* "bread, offering"[7] or *wáa* "or, if"[36]; *xec-* open |

**Line notes (2 and 3).** These are boss combat-cries, mostly skill-names, so every token above is given a candidate root, but most stay soft rather than committed. The split runs clean along the corpus's seams: Ahuatotli's tokens are Nahuatl (the *xi-* imperative, *-tl* nouns, candidate roots *tlatla* "burn," *cua* "eat," *āzcatl* "ant"), while Mektul's are core Yucatec (*k'áak'* "fire," *che'* "wood," *ik'* "wind/spirit," *k'áat* "ask," and the attested *táak'in* "gold"), with one *r* (*koriek*) flagging the K'iche' seam. None is promoted to §8. Both speakers are gathered with the other figures in §11.

---

## 8. Combined lexicon

**Confidence key:** **C** committed (verified root, sound phonology); **L** lore-anchored (fits the narrative); **C+L** both. All four texts and the Text 5 captures share this one lexicon, together with the confirmed standalone Vaal names (the Beast *pochiti*, the tomes *Eztli Pilli* and *Guatelitzi*); any standalone name whose reading is still soft stays in §9. A token earns a place here only when both its root *and* its surface-to-root derivation are settled; tokens with a plausible-to-verified root but one unresolved derivational step (an irregular sound-change, an inferred or contested segmentation, no cross-check) are held in §9.4 instead. Superscripts in the **Source** column link to the numbered citations in §14.

| Token | Source | Gloss | Conf. | Notes |
|---|---|---|---|---|
| Aiokmo | Nah. *aocmo*[10] | no more, no longer | C | Text 1 form; cf. Text 3 *'Ayok*. |
| akal | Maya *akal* "pond"[7] | still / eternal waters | C | Shadow sense: the nightmare realm. |
| anab | Classic Maya *anaab*[7] | court-servant, attendant | C | Attested courtier title; replaced an earlier Taíno guess. |
| ascensionada / ascenada | Rom. *ascensión* + *-ada*[21] | ascended, risen | C | First-identified Romance loan (others: *xefe*, *u'tra*, *échelo*, *fukuur*). |
| A'te / U'Te / Yatle | Maya *at / yan* presentative[7] | behold / here is / there stands | C+L | The offering gesture; presents each thing to the goddess. Shared across all three texts. |
| atla | Nah. *atl* "water" (+ *-tlan* "in/at")[10] | the water / upon the water | C | |
| Atziri | Nah. *ātl* "water" + rev. *-tzin*[10,13] | the queen (name) | C+L | Water / reflection / vanity motif. |
| 'Ayok | Nah. *aocmo / ayoc*[10] | no more, no longer | C | Same root as *Aiokmo*. |
| cha'tsoke | Maya *ka'a* "again" + *ts'ook* "end"[7] | the ending once more | C | |
| che' | Maya *che'* "tree, wood"[7][36] | tree, wood | C | In *kahk-tche* (Text 5, Mektul) = *k'áak' che'* "fire-wood, firebrand." |
| chikula' | Maya *chíikul*[7] | sign, omen | L | |
| ek | Maya *ek'*[7] | star; also black / dark | C | |
| Ela | Maya *el / elel* "to burn"[7][36] | burns, it burns | C | Text 4 catechism; same root as *elba*; regular *el → ela* stylization. |
| elba | Maya *el* + *ba'* "self"[7] | burn out, extinguish | C | |
| -en | Maya *-en / teen*[7] | me, I | C | In *ta' en* (Text 3, speech 1). |
| Eztli Pilli | Nah. *eztli* "blood" + *pilli* "noble, prince"[10] | "the Blood Prince" (a forbidden Vaal tome) | C+L | Standalone tome name[6]; full roots, no stylization; the pairing is an attested collocation (*cualli eztli* "good blood"). See §9.6. |
| Guatelitzi | (name)[38] | the Architect of Flesh (a Vaal architect of the Temple of Atzoatl) | C+L | Standalone name, from Zelina's *"Tome of Guatelitzi"*; the Vaal flesh-and-immortality architect whose rooms culminate in the *Sanctum of Immortality* (*"Flesh rending for life unending"*). Nahuatl-flavoured; *-tzi* from reverential *-tzin*. See §9.8. |
| Gyan'uks | Nah. *yancuic* "new"[10] | the new ones → "(your) new children" | L | The /g/ marks the Nahuatl source. |
| 'Ibil | Maya *il* "see" + *-bil*[7] | the seen → the flesh (laid bare) | C+L | Canonical game form *'Ibil* (per *VaalSermon_06*); an earlier draft wrote *Íbil*. |
| ich | Maya *ich(il)*[7] | in, within | C | "within the altar." |
| i'chian | Nah. *ichan* "his/her home" (*chantli* "home" + *i-*)[10,22] | the dwelling, her house | C | *niáach ichan* "far within her house", literally Atziri's royal temple at Lira Vaal, where the Commander stands. The root *chantli* survives in modern Mexican/Central-American Spanish *chante* "house, home" (see §12). |
| ik'bala | Maya *ik'* + *ba'*[7] | spirit-self, soul | C | |
| ikba'yucane | Maya *ik'* + *ba'* + *-ane* hon.[7] | the deathless-spirited ones | C | |
| Ik'eche | Maya *ik'* "spirit/breath" + *-ech* "you" + *-e* voc.[7] | "O spirit / thou art breath" | C | |
| ik'el | Maya *ik'* + *-el*[7] | the spirit, the unseen | C+L | |
| itsok / itzil | Maya *iitz* "sap, essence"[7] | blood, essence | C+L | *le'itzil* = "the essence." |
| jare | K'iche' *are'* "he, she, it; it is, that is" (focus) / *ri* "the"[47] | connective: "thus, and so" | C | The /r/ marks Highland Maya; grammatical glue, not a content word. Now confirmed in a dedicated K'iche' dictionary[47] (Christenson lists *are'* as the focus pronoun and *ri* as the article), upgrading the earlier phonology-only note[17]. The apostrophe form *jare'* is attested in-game (Text 5). See §9.2. |
| k'áak' (kahk) | Maya *k'áak'* "fire"[7][36] | fire | C | Mektul's cry *kahk-tche* (Text 5); distinct from *ek'* "star, dark." |
| Kextal | Maya *k'ex* "substitution → transform"[7] | transformation, ritual renewal | C | Rendered "transform us." |
| ki' (Kí') | Maya *ki'*[7] | good, delicious, sweet | C | A blood-drinker's relish: "Sweet!" |
| kifba | Maya *k'i'ik'* "blood" + *ba'*[7] | the heart, lifeblood | C+L | Distinct from *itsok*'s *iitz*. |
| kíimil | Maya *kíimil*[7] | death, the dead | L | |
| kilya | Maya *ma'* "not" + *kíim* "death"[7] | undying ("no-death") | C | Undying-in-legend re: Zerphi. |
| ko'janti | Maya *ko'* "come" + *han-* "eat" + *-ti*[7] | come, devour | L | Addressed to Atziri. The *-ti* here is best read as the Yucatec relational *ti'* (contrast the Nah. inchoative *-ti* in *pochiti*, §9.5). |
| kujkuali | Nah. *cualli*[10] | good, worthy | C+L | |
| kutsen | Maya *kutz* "sacrificial bird"[7] | the offering | C+L | |
| kux / kuxkal / kuxte' | Maya *kuxtal*[7] | life, the living | L |
| k'ux (quxzeh) | Maya *k'ux* "to bite, gnaw; rancor"[7][36] | bite!, be fierce | C | Ejective /k'/ (corpus *q*), distinct from *kux* "life"; in *quxzeh* (Text 4) the *-zeh* coda is a non-morphemic tail (cf. *Otsuks -s*). See §9.11. | |
| le / le' | Yucatec article *le…o'*[7] | the | L | |
| líimek | Maya *lu'um* "earth"[7] | those in the earth, the dead | L | Replaced an earlier Tagalog guess. |
| ma | Nah. *mā* / Maya *ma'*[7,10] | optative "may"; negation "not" | C | |
| máax | Yucatec *máax* "who?"[7] | who (interrogative) | C | New in Text 4 (§6); the same word ruled out a "crush" reading in §9.4. |
| Ma'oxe | Maya *ma'* "without" + *xok* "count"[7] | the countless / numberless spirits | L | "Without-count" → innumerable; Atziri's faithful. See §9.1. |
| mucane | Maya *muk'* "strength" + *-ane*[7] | the mighty, the enduring | C | Shadow: *muk* "bury." |
| mujuk' | Maya *muk'* "strength, force"[7] | strength, might | C | Confirmed by *"u mujuk' le mucane"* = "the might of the mighty." |
| náach (niáach) | Maya *náach*[7] | far, distant | C | |
| nochira | Nah. *nochi / mochi*[10] | all, everything | C | |
| pochiti | Maya *poch* "hungry, gluttonous"[8] + Nah. inchoative *-ti*[14] | the Hungering One (Atziri's name for the Beast) | C+L | Standalone word, not from Texts 1–4[6]; *ch* = /tʃ/; lead reading, a *pōchōtl* "ceiba / protector" co-reading is logged in §9.5. |
| qexcan | Maya *k'ex* "transform" + *-can* (Nah. locative "place of")[7,10] | place of transformation | C+L | The temple as crucible. A Maya root + Nahuatl suffix cross-graft. |
| sakilja | Maya *sak* "white, pure" + *ha'* "water"[7] | the sacred white draught | C+L | Cf. ceremonial *sak ha'*; blood-metaphor *sak juy ch'ich'* "white stirred blood." |
| ta'nuk | Maya *nuk / nojoch* "big, great"[7] | the great one | C | *nuk* committed; *ta'-* element soft. |
| tala | Maya *taal* "to come"[7][36] | come, comes | C | Free form of the verb (cf. the bound *a'tul*, §9.9); regular terminal-vowel stylization *taal → tala*. Text 5. |
| te | Maya *ti' / te'*[7] | of / to (relational) | C | |
| Teoyuxtlane | Nah. *teōtl* "god" + *Yux* (Yutsal) + *-tlān* "place" + voc. *-e*[10,13] | place of divine Utzaal | C | |
| Ti | Maya *ti'*[7] | to / for you (dative) | C | Fixes Atziri as recipient. |
| til | Maya *til*[7] | to burn, kindle | C | Death-as-fire. |
| tlapec / yotlapek | Nah. *tlapechtli* "platform, scaffold, altar-bed"[10] | the (sacrificial) altar-platform | C+L | *yo-* prefix unexplained (poss. Nah. *yōl-* "heart"?). |
| Tlaxye' | Nah. *tlāl- / tlācah*[10] | land, people | L | Replaced an earlier Quechua guess. |
| tlayeb | Nah. *tla-* + *tlayohua* "night"[10] | the (sacred) dark | C+L | |
| tul | Maya *tul* "decline"[7] | wane, dwindle | C | Decay-as-fire. |
| Tzokan'te / tzok | Maya *ts'ook*[7] | end, the last | L | |
| u | Maya *u-* (Set A 3rd person)[7] | his, her, its; the | C | *u mujuk'* "his/the might." |
| uch' / pu uch' | Maya *uk'* "to drink", **or** *puuch'* "to crush"[7] | drink / crush | C | Ambiguous: *uk'* fits the draught theme; *puuch'* fits his "Crush!" barks. |
| u'tra | Rom. Spanish *otra*[21] | another | C | One word (not *u* + *tra*); the /r/ flags the Romance loan. |
| Vaal | (name)[5] | the people, the empire | C+L | |
| waaj (waja) | Maya *waaj*[7] | bread; **altar-offering** | C+L | Food offered on Janal Pixán altars, i.e. an offering. |
| Xatlene | Nah. *xōtla* "to kindle, blaze, glow"[10] | kindle! / the kindler | L | Text 2; *x* = /ʃ/, *-ne* epithet-former (cf. *mucane*, *yuquia*); root verified, one soft step (the *o→a* vowel). |
| xefe | Rom. Spanish *jefe* (archaic *xefe*)[21] | chief, commander | C | Romance loan; the in-game title is *Royal Commander*. |
| xi | Nah. *xi-*[10] | imperative "do! / make!" | C | |
| xu'te | Maya *xul* "end" + *te'*[7] | the end | C | |
| yax / Yaxe | Maya *yax*[7] | first, new, green | L | |
| yuquia | Nah. *yocoya* "create, devise"[10] | the made, the wrought | L | Cf. *Moyocoyatzin* "self-creator." Replaced an earlier Quechua guess. |
| Yutsal / yutsal | (name)[5] | Utzaal, a major Vaal city, Doryani's seat of power (not the capital) | C+L | Embedded in *Teoyuxtlane*. |
| Zerphi | (name)[5] | unaging Vaal noble | C | |

### Recurring morphemes

*ik'* (spirit / breath / dark); *ba'* (self); *-ane / -yucane* (honorific); *teo-* (god); *-tlān* (place); *tla-* (Nah. object prefix); *le* (the); *ko'* (hortative); *u-* (Maya Set A 3rd person); *-ti* (Yucatec relational *ti'* / Nah. inchoative); *-ada* (Romance); *ma'* (negation).

---

## 9. Appendix: recorded alternates & open questions

Every candidate considered, kept for future reference.

### 9.1 Ma'oxe: *ma'* "without" + a second root

| Parse | Meaning | Status |
|---|---|---|
| **ma' + xok** "count" | **the countless / numberless spirits** | ★ chosen, cleanest phonetics (the *x* lands exactly) and best theme |
| ma' + óol "spirit, will" | the spent / will-less spirit | alt, strongest single root (*óol* is everyday Yucatec), but needs an *l→x* drift |
| ma' + óoxol "heat" (?) | the cold spirit | ⚠ root *óoxol* unverified |
| máax + *-e'* | (would read "whose spirit?") | ✗ *máax* = "who?", not "crush" |
| ma'ax / *mix* "none" | "not even a spirit" | ⚠ the real "none" is *mix*; conflated |

### 9.2 jare: anomalous /r/ marks a non-Yucatec/Nahuatl source

| Parse | Meaning | Status |
|---|---|---|
| **K'iche' focus/demonstrative particle** (*are' / ri* family) | connective: "thus, and so" | ★ chosen, explains the /r/ (K'iche' keeps it), fits the connective slot, no semantic stretch. The exact form *jare'* now appears in-game (Text 5, the Kamasan Smith), confirming the apostrophe form; the category, a K'iche' connective, remains the answer. |
| K'iche' *jarem / jarik* | decay, wearing-out | alt, phonologically fine, root unverified |
| Yucatec *jáal* + *l→r* | to the edge / limit | alt, real word, but the *l→r* swap is a stretch and leaves the /r/ unexplained |
| Nahuatl *xalli* (*x→j, l→r*) | dust, ash | ⚠ low, requires two corruptions |

**Xinkan / Aztecan check.** The /r/ is not Aztecan: Nahuatl and Nawat have no native /r/, and Nahuatl's demonstratives (*in / inin / inon*) carry none.[27] Xinka *does* have a tap /r/, but its attested demonstrative is the third-person *nah*, no *are'*-type form is on record.[26] So K'iche' *are' / ri* remains the one attested fit, and the /r/ still marks the Highland-Maya seam.

### 9.3 Other resolved holdouts

These weak or cross-family guesses were replaced with attested Maya/Nahuatl roots, keeping the whole text inside its geographic palette:

| Token | Rejected guess | Adopted root |
|---|---|---|
| anab | Taíno *naboría* | Classic Maya *anaab* "courtier" |
| Tlaxye' | Quechua *llaqta* | Nah. *tlācah* "people" |
| líimek | Tagalog *limot* | Maya *lu'um* "earth" |
| yuquia | Quechua *yuya* "memory" | Nah. *yocoya* "create" |

### 9.4 Text 3: proposed in-palette parses (soft, not committed)

**Why these sit here and not in §8.** Membership in the committed lexicon turns on the *whole token's* security, not on whether a dictionary holds the root, and most roots below are in fact attested. What keeps each token here is one unresolved step in its derivation: an irregular sound-change outside the established correspondences (the *a→u* of *buxa*, the *o→u* of *Eche lu* and *puxe*), a truncation (*inib*), a segmentation reasoned out rather than looked up (*Donuks*, after no Vaal name matched), imperfect phonetics (*fukuur*, *soxsal*), or two live candidates (*te'moxti*, *daka*, *pu*). "Strong" therefore means "verified root, best-available parse," not "settled." And unlike the committed tokens, which map by regular rule and are often cross-confirmed by recurrence or the game files, these appear once, in Text 3, with nothing yet to check them against. A cleaner phonological account or a second attestation would graduate any of them; *nochbe* (built only from the committed *nochi* + *ba'*) and *inib* (*in* + the committed *'Ibil*) are nearest the line.

A lore check found no Vaal name matching *Donuks* or *puyao* (checked against Kamasa, Kopec, Arakaali, Kishara, Xibaqua, Tetzlapokal, Ketzuli, Napuatzi, Doryani, Zolin/Zelina), so these are decomposed rather than looked up. Notably, three resolve toward *the drink*, reinforcing the rite as a communal draught.

| Token | Proposed parse | Reading | Strength |
|---|---|---|---|
| Donuks | Maya *to'on* "we/us" + *uk'* "to drink" | "we who drink / our draught" | strong, both roots solid; *-uks* coda matches *Gyan'uks*; the initial *t→d* now read as **post-vocalic voicing** after *atla* (proposed environment), consistent with the commander's Spanish-influenced dialect |
| puxe | Maya *pox* ("posh"), ceremonial corn/cane liquor (Highland Maya)[7] | the sacred drink | strong, fits the K'iche'/Highland seam and the drink theme |
| inib (Kí' inib) | Maya *in* "my" + *'Ibil* "flesh" | "my flesh" → *"Sweet, my flesh!"* | strong, both roots already verified; minor *-ibil→-ib* contraction |
| nochbe (Eche lu nochbe) | Nah. *nochi* "all" + Maya *ba'* "self" | "all of ourselves" | strong, both roots verified; better theme than *noh beh* "road" (now an alt) |
| buxa (u'tra buxa) | Maya *ba'ax* "what, what-thing" (interrogative; ends in *x* = /ʃ/)[7] | "another such thing / another one", the commander dismissing the intruder | strong, verified root, **preserves *x* = /ʃ/** (unlike *búuk*), terminal-vowel stylization matches *Ma'oxe / puxe*; soft point is the *a→u* vowel drift, now read as **conditioned**, the rounded /u/ of the preceding loan *u'tra* plausibly triggers the rounding (a proposed environment, not a free drift) |
| Eche lu (Eche lu nochbe) | Spanish *échelo* = *eche* (formal imper. of *echar* "throw, cast, pour out") + *lo* "it"[21] | "pour it out / cast it out, all of ourselves!" | strong, verified root; the *ch* /tʃ/ is **etymological** (Lat. *iactare* → *ch*), so it supplies the very sound *he'ela'* lacked; only drift is *o→u*; fits the Commander's Spanish-martial seam and imperative register. In-palette alt: Maya *-ech* "you" + *le* "the" → "to you, the all of ourselves", sound, but leans on a bound suffix used freely plus a larger *e→u* shift. Note that *he'ela' / he'la'* "here it is, tenga" is itself attested in living Yucatec (Belize)[30], so it is a genuine alternative, but at two syllables and lacking /tʃ/ it still fits *Eche lu* less closely than *échelo* |
| daka | Spanish *daca* "give it here" (RAE *Autoridades*: a defective imperative, contraction of *da acá*)[20] | "give / bring [the drink]", imperative, fitting *Xi … puxe* | source well-diagnosed, lexical choice soft, the /d/ is loan-only across the palette, so (like /f/) it marks a **Romance** loan, and the Commander's speech already carries *xefe*, *u'tra*; *daca* is the best Spanish fit, though not the only conceivable imperative. The Maya alternative *taak* "to want" needs an unattested *d→t* respelling and reads weaker, the bigger leap, not the smaller one. Cross-checked against the zone's other families (§12): Aztecan supplies the right *meaning*, *maca / maka* "to give," which would suit the *xi-* imperative, but its /m/ onset cannot yield the form *daka*; Xinka has a native /d/ yet no attested "give" verb resembling *daka*. So *daca* keeps the form, now with its "give!" sense independently echoed by Nahuan *maca*[27] |
| fukuur | Rom. Spanish *fulgor* "brilliance, blaze" (Lat. *fulgur* "lightning")[21] | "the blaze / lightning-flash!" | moderate, the Commander is fire-based and breathes fire, so this fits its blaze imagery (*A'te fukuur!* "Behold the blaze!"; the English bark "Flaming Glory!"); /f/ = Spanish; phonetics imperfect (defer to ear) |
| soxsal (ko'soxsal) | Nah. *xoxoc-* "raw, fresh, green" (*xoxoctic/xoxouhqui*) | "the raw/fresh [blood]!" | moderate, real root; *xoxoc→soxsal* imperfect (alt: *sáasal* "light"; *sotz'* "bat") |
| puyao / Na' puyao | Nah. *poyahua* "to darken, redden" | "the reddened (offering)" | soft, common noun, not a name (*"u'te puyao"* ∥ *"a'te itsok"*) |
| te'moxti | *te'* "of" + Nah. *mochi* "all" **or** Maya *mux* "grind, crush" | "of all" / "of the grinding" | moderate, two viable candidates |
| pu (pu uch') | proclitic intensifier, or part of *puuch'* "crush" | "drink deep" / "crush" | soft |

**Rejected on verification:** *fukuur* ← Maya *púukul* "destruction" (root unattested + ad-hoc *p→f*; the /f/ is better explained as Spanish). *puyao* ← Maya *puy* "slice" + *ha'* "water" (*puy* "cut" unattested, the real Yucatec cut-verbs are *xot, ch'ak, kup*).

### 9.5 pochiti: Atziri's name for the Beast

*Not from Texts 1–3: a standalone Vaal word Atziri speaks in her PoE2 encounter.[6] She has no other Vaal lines there; this is her one word for the Beast, the primordial entity she communed with, triggering the Cataclysm. Two attested roots fit, and the lore supports both at once.*

| Parse | Reading | Status |
|---|---|---|
| **Maya *poch* "gluttonous, hungry, craving"** + Nah. inchoative *-ti* (ligature *-i-*)[8,14] | **"the Hungering One / the Devourer"** | ★ lead, root verified to RAE level (*poch* 'goloso, hambriento'; Yucatec *poch* "antojo, deseo"); phonology exact (*ch* = /tʃ/); fits the Beast that Atziri sustains with sacrifice |
| Nah. *pōchōtl* "ceiba / silk-cotton tree"[11,12] (UNAM GDN: "métaphor., protecteur"; the *āhuēhuētl + pōchōtl* shade = a ruler's authority; the Maya *axis mundi* world-tree linking Xibalba, earth, sky) | "the sheltering tree / Great Protector" | ○ co-reading, root verified, but **no in-game lore supports a protector/"Mother" Beast** (see note); rests on the *pōchōtl* etymology alone and needs *-ōtl → -iti*. Weaker than the *poch* reading |

**Correction.** An earlier version read these two roots as a deliberate duality, devourer *and* nurturing "Mother", on the claim that an Aggorat cult venerated the Beast as "Mother." That claim is unsupported: Aggorat is simply a Vaal city of altars and zealots, with nothing tying the Beast to a "Mother" cult, and the "mother / brood / family" theme in present-day Act 3 belongs to a separate boss, the Queen of Filth, whose fight spawns "Younglings" and who calls the monsters her children, not to the Beast. So *poch* "the Hungering One" is the reading that actually fits the lore (the devourer Atziri feeds); *pōchōtl* "ceiba / protector-tree" survives only as a phonological alternative, without thematic support.

**The *-iti* tail, worked out.** Because the meaning is fixed here ("the one that is hunger"), the suffix's job is given and only its source was open, and it resolves cleanly inside the palette. It is Nahuatl **-ti**, the denominal inchoative "to become / be X" (attested: *tlācati* "to be born," *teti* "to harden into stone," *cuauhti* "to stiffen like wood"), joined by the standard Nahuatl ligature **-i-** (the same *-ti-* seen in *tlal-ti-cpac*, *Tenoch-ti-tlan*). So *poch* + *-i-* + *-ti* = "(that which) is / becomes hunger", a Maya root inflected with Nahuatl morphology, exactly the cross-graft already on record in *qexcan* (Maya *k'ex* + Nah. *-can*). The one soft step is reading the resulting stative as a personified name, which is how the conlang builds epithets throughout (*Xatlene* "the kindler," *yuquia* "the made"). Note the surface *-ti* also ends *ko'janti*, but there it is better read as the Yucatec relational *ti'* "to / at", so the two are homophones, not one morpheme.

*(Now carried in the §8 lexicon; the two readings and their lore basis are kept here.)*

**Clarity it gives elsewhere.** *pochiti* completes a three-way minimal contrast of look-alike roots the orthography deliberately keeps apart: **poch** /potʃ/ "hunger" (*ch* = /tʃ/) vs **pox** /poʃ/ "the *posh* ceremonial drink" (*x* = /ʃ/, the soft reading of *puxe*) vs **puuch'** /puːtʃʼ/ "crush" (the *uch' / pu uch'* alternate). Three sounds, three meanings, all attested, independent confirmation that the conlang's *ch / x / ch'* spellings track real Maya phonemic distinctions, which retroactively supports the *x* = /ʃ/ rule used for *buxa*. The *pōchōtl* co-reading is itself corroborated by a living reflex: *pochote* (the ceiba) and colloquial *pochotón* "husky, thick-built" (see §12).

### 9.6 Eztli Pilli: a Vaal tome of forbidden blood-knowledge

*Like *pochiti*, a standalone Vaal name, not from Texts 1–3: the title of an in-game tome of forbidden, volatile knowledge, deemed too dangerous to use.[6] Pure Classical Nahuatl, and unusually un-stylised, two full roots with their absolutives intact.*

- **eztli** "blood"[10], well attested (Sahagún, *Florentine Codex*). The *z* is Nahuatl /s/, not the alien /z/, so it stays inside the palette.
- **pilli** "noble, lord; prince; child"[10], as in *Xōchipilli* "flower prince," *Piltzintecuhtli* "young prince."

So *Eztli Pilli* = **"Blood Noble / Blood Prince."** The pairing is not merely plausible but **attested as a collocation**: Classical Nahuatl *huey pilli, cualli eztli* "a great noble of good blood."[10] A forbidden grimoire of Vaal blood-magic titled "the Blood Prince" sits squarely in the corpus's blood-and-lineage register. Confidence: roots **C** (verified, the collocation itself attested), reading **C+L**.

This is the cleanest non-text token yet, both roots full and unaltered, and a second Vaal "tome" reference beside Zelina's *Guatelitzi* (§9.8); unlike that one, *Eztli Pilli* parses without residue. *(Now carried in the §8 lexicon.)*

### 9.7 Still open (kept open, not forced)

| Token | Note |
|---|---|
| ukto (Ela tlayeb ukto) | Stands in the offering-slot parallel to *kutsen*, so a noun ("the dark [offering]"); nearest guesses are *uk'* "to drink" (a libation) or Nah. *octli* "(sacred) drink," but neither is a clean phonological fit, so it is left open. Text 4 catechism. |
| ta' (ta' en) | Maya *ti'* "to/for" **or** *taak* "to want" (needs *k*→glottal); "no more for me" / "I want no more." A third Yucatec homophone, *ta'* "excrement"[30], is attested but contextually impossible in *ta' en* / *ta'nuk*, so it is excluded |

### 9.8 Guatelitzi: identified as the Architect of Flesh

Zelina's enrage bark names a Vaal tome, *"Tome of Guatelitzi."* This was earlier logged as an unattested stem and reconstructed (below) as a *cuauh-* "tree" compound. **That reconstruction is now withdrawn: *Guatelitzi* is an attested in-game proper name.** *Guatelitzi, Architect of Flesh* is one of the Vaal Architects of the **Temple of Atzoatl** (PoE1 Incursion, v3.3.0; core v3.5.0).[38] His incursion-room line runs *Pools of Restoration*, *Sanctum of Vitality*, *Sanctum of Immortality* (room flavour: *"Flesh rending for life unending"*), and his signature item modifiers are all maximum Life, Energy Shield, and Life / Energy-Shield regeneration: an architect whose craft is flesh and unending life, an immortality experimenter. (Identification contributed by *Tenebris-Umbra*.)

This resolves the token cleanly and on theme. The PoE2 Vaal temple reuses Atzoatl's room-grid and lore, and the Vaal there take the player for the old "demon of Atzoatl" (§10). A Blood Priestess invoking the *"Tome of Guatelitzi"* is naming that flesh-and-immortality architect: a grimoire attributed to the Vaal who chased unending life through flesh fits Zelina's blood-magic register exactly, and it pairs with the other named Vaal tome, *Eztli Pilli* "the Blood Prince" (§9.6). So *Guatelitzi* is **onomastic**, a known character name, not a common-noun phrase to be parsed; it is now carried as a confirmed name in §8.

**The earlier etymological reconstruction (superseded, kept for the record).** Before the lore identification above, the name was reverse-engineered from its phonology; that analysis is preserved here as the secondary account it has become. Like the other Atzoatl architects (*Ahuana, Atmohua, Cholotl, Citaqualotl, Estazunti, Hayoxi, Jiquani, Matatl, Opiloti, Paquate*), *Guatelitzi* is Nahuatl-flavoured and ends in the reverential *-tzi(n)* seen elsewhere in the corpus (*Atziri*, *Napuatzi*), so the *Guate-* onset was read as a hidden Nahuatl /kʷaw/ root:

- **Guatemala from Nahuatl Cuauhtēmallān "place of many trees"**[25], *cuahui(tl)* "tree" + *tema* "to fill / abound" + *-tlan / -lan* "place of." The name is the Nahuatl calque of K'iche' *k'iche'* "many trees / forest," the macro-name the Highland Maya gave their own land. Spanish regularly renders Nahuatl /kʷaw/ as *gua- / cua-* (*Cuauhtémoc* → *Guatemoc*), so the *Guate-* of both *Guatemala* and *Guatelitzi* was taken to resolve to Nahuatl **cuauh- "tree."**
- **-tzi** = the Nahuatl reverential ***-tzin***, with the final *-n* routinely dropped in the corpus (cf. *Atziri*, *Napuatzi*).
- **-teli- / -tel-** (medial) was the soft, unresolved element. The cleanest fit mirrored the *Cuauhtē-* of *Cuauhtēmallān*: *cuauh-* "tree" + the *-tē-* of *tema* "to fill / abound," an "abounding-tree" stem, with *-li-* a connective before *-tzin*. Plausible, never nailed down.

That yielded *Guatelitzi* ≈ Nahuatl *cuauh-* "tree" + reverential *-tzin* → *"the revered tree / honoured forest,"* a reading that sat neatly on the ceiba theme already in play (*pōchōtl*, §9.5) and on the K'iche' "many trees" identity of the region the language is built from, a reasonable parse for what then looked like an unattested coinage. It is set aside now only because the referent is known: *Guatelitzi* is a person's name, not a descriptive phrase, so the "tree" gloss falls away even though the Nahuatl-flavoured phonology that suggested it still holds.

**Xinkan checked, then set aside.** Xinka, a language isolate of southeastern Guatemala, was tested as an alternative source while the token was still open; it supplies nothing (attested Xinka basic vocabulary shows no *guate*-like root: "water" *uy*, "fire" *ura*, "sun" *parri*, "black" *tz'uona*).[26] The question is moot now that the token is a known proper name, but the cross-check is kept for method.

### 9.9 Text 4: token analysis & root-search

*The text itself is §6; this section holds the token-by-token analysis and the root-search behind the soft readings.*

| Token | Parse | Reading | Confidence |
|---|---|---|---|
| Máax | Yucatec *máax* "who?"[7] | who | ★ attested (now in §8) |
| ka | Yucatec dependent / subjunctive *ka(j)*[7] | "that / when (you)…" | ○ real particle; function here soft |
| ti | Maya *ti'* "to / at"[7] | to | ★ committed (§8) |
| U'te | Maya presentative *(u) yan / at*[7] | "behold / here stand" | ★ committed (§8, *A'te / U'Te / Yatle*) |
| mucane | Maya *muk'* "strength" + *-ane*[7] | "the mighty" | ★ committed (§8) |
| en | Maya *-en* "me / I"[7] | me | ★ committed (§8) |
| a'tul | **Set A 2nd-person *a-* "you / your"** (confirmed, *tuyo* "your" = *a*[36]) + *taal* "to come"[7][36]; soft point is the *taal → -tul* raising (aa→u). Alt: animate classifier *-túul* "one [being]" | "(that) you come" | ○ soft, the prefix is attested; the *taal→tul* drift is the open step |
| cheyel | **Nah. *chiya / chīa* "to watch, wait, lie in wait"[33] + Maya status *-el*** (*chīya* → *chey-*); the Yucatec watch/sentinel field was searched and set aside **on phonology**, *ch'úuk* "lie in wait, ambush," *cha'an* "behold, watch," *pa'at* "wait," *kanan* "guard"[36] (all apt in sense, none a path to *cheyel*); also set aside: *chéel* "rainbow," *che'eh* "laughter," *che'*+*-el* (a noun), *ch'i'ibal* "lineage" | "to keep watch / stand sentinel" | ○ soft-leading, attested sentinel verb, on-theme; the native field offering no closer form is what justifies the Nahuatl graft |
| Axba | Yuc. *ba'ax* "what" (confirmed[36]) by **metathesis *ba'ax → axba***, an exclamation "What!?", parallel to *buxa* from the same root (§9.4); *aax* "wart" and *ba'ate'el* "fight" are false friends | "What!?" | ○ soft, root attested; the metathesis is the open step |
| Kíibsa' | Maya *kíim* "die" + causative **-s**[28] + deictic *-a'* (Yuc. *kíims* "to kill") | "kill (it)!" | ○ soft, well-framed, but needs an *m→b* spelling |
| ta' | open token (*ti'* vs *taak*; here perhaps "to / at") | "to / before" | open, same item flagged in §9.7 |
| Otsuks | Yucatec *tsuk* "cluster, company" (Cordemex)[31] framed by the Nah. exclamatory/presentative **o** "oh! / behold!" (Molina: *he aquí*)[34], a Nahuatl-particle + Maya-root graft (cf. *qexcan*, *pochiti*); only the *-s* coda open | "Behold, the company! / Company, fall in!" | ○ soft, root **and** onset particle now attested; only the *-s* coda open |
| quxzeh | Maya ***k'ux* "to bite, gnaw; ache; rancor"**[33] (modern *k'uux* "morder; odiar; rencor"[36]), the corpus *q* marks ejective /k'/ (cf. *qexcan* ← *k'ex*), so the root is *k'ux*, not plain *kux* "life"; *-zeh* tail still not an attested suffix | "bite! / be fierce!" | ● root closed: *k'ux* "to bite" attested in Cordemex and the modern wordlist[7][36], now in §8; the *-zeh* coda is a non-morphemic tail (cf. *Otsuks -s*). See §9.11 |

**Root-search, Otsuks, -zeh (recurrence vs. attestation).** The new captures settle one question and leave another open. *Otsuks* now **recurs as a fixed opener**, the same form across Tizoc, Cotan, and Axilo, and again in *Otsuks, quxzeh!*, so by position and function it is unmistakably a lexicalised drill-command. The first survey of the *soldier / warrior / men* field found no phonological fit, Yucatec *holkan* "soldier," Nahuatl *yāōquīzqui* "soldier," *tiacāuh* "valiant man," K'iche' *achi* "man," *ajlab'al* "warrior" all sit far from */otsuks/*[29]; the Nahuatl **Otōntin** warrior society (the Otomi shock-troops who fought beside the *cuāchicqueh* behind *Cuachic*, §4, §10) is the closest in *kind*, but *otōntin → otsuks* has no regular sound path, so it was noted, not adopted.[29] The breakthrough is in the **core layer**: Yucatec **tsuk** "group, cluster, bunch", Cordemex glosses *tsuk* (*tzuc*) as *grupo de árboles pequeños, montecillo* ("a clump of small trees, a thicket"), beside "crest, tuft" and "animal's crop"; and, **now verified directly in the Cordemex text to hand** (the dictionary copy added to the project), it also appears under *much'* as a **numeral classifier for clusters/heaps**, *hun tsuk* "one cluster," *ka' tsuk* "two," *tsuk-en-tsuk* "in clusters."[31] A modern peninsular wordlist independently lists *tsúuk* beside *múuch'* for *montón* "heap"[36], so the root is attested across both colonial and present-day Yucatec. That classifier use is the clincher: a form whose grammatical job is to *count groups* extends to a body of men with no stretch at all, so *Otsuks!* reads as a unit-call, "Company! / Fall in!", native Yucatec, not a loan. What stays open now is only the coda. The *o-* onset, earlier set aside as a phantom affix, is in fact an **attested Nahuatl particle**: Molina (1571) records *o* as an exclamatory interjection ("del que está afligido y hace exclamación") and as the adverb *he aquí* "behold / here it is."[34] That makes *Otsuks* a Nahuatl-particle + Maya-root graft on the established *qexcan / pochiti* pattern, *o* "behold!" + *tsuk* "company", and its presentative sense rhymes with the Vaal presentative *U'te / A'te* already in the corpus, so *Otsuks!* reads naturally as "Behold, the company!" / "Company, fall in!" The lone open element is the *-s* coda, best taken as the same stylised romanization seen in *Donuks* and *Gyan'uks* (a closing *-s/-ks* with no morpheme behind it) rather than a Yucatec affix. So *Otsuks* moves from "no attested root" to **attested root, unresolved morphology**, a soft reading, no longer rootless but not yet committed. Its recurrence as a fixed opener also kills the "-uks suffix" idea independently: the coda carries no meaning, it just closes a fixed command; a non-lexical drill-cadence (cf. English "Hut!") is now only a fallback. (*-uks* stays a romanization artifact, *Donuks* ← *uk'* "drink", *Gyan'uks* ← the *-cuic* of *yancuic* "new", not a morpheme.) *-zeh* likewise stays unidentified: Yucatec's causative is **-s / -kun(s)**, not *-zeh*, and Nahuatl has no *-zeh* (agentive *-keh / -queh*, reverential *-tzin*),[28] so the root carries the sense, now read as Yucatec **k'ux "bite, gnaw, sting; rancor"** rather than *kux* "life," since the corpus's *q* marks the ejective /k'/ (cf. *qexcan* ← *k'ex*), giving *"Otsuks, quxzeh!"* the sharper drill sense "Company, bite! / be fierce!"[33][35], while the *-zeh* tail is left open. (A neat Spanish reflexive *-se*, as in *cuídese*, would fit *kux* "live" → "keep yourselves alive," but it cannot ride the better-supported *k'ux* root, so it is logged as a competing reading, not adopted.) Neither *Otsuks* nor the soft tokens above are admitted to §8 until a cleaner root or a parallel attestation appears.

*Dictionary pass on the three soft tokens (full Cordemex [31,32] plus the reachable colonial and modern dictionaries):* **cheyel** has no Yucatec headword that fits the *Máax ka ti __?* "who are you to __?" frame: the native watch/sentinel verbs, *ch'úuk* "lie in wait," *cha'an* "behold," *pa'at* "wait," *kanan* "guard"[36], fit the sense but offer no path to the *form* "cheyel," and the noun candidates (*chéel* "rainbow," *che'eh* "laughter") fit neither. With the Yucatec field exhausted, the frame is best filled by **Nahuatl *chiya* "to watch / wait / lie in wait"** + Maya *-el*[33], a sentinel verb suited to a sentry challenge, a soft-leading cross-graft (the mirror of *pochiti*), not committed. **a'tul**'s *a- + taal* "to come" reading remains the best sentry-challenge fit, with the animate classifier *-túul* noted only as a weaker alternative. **Axba** is most likely onomastic, a sergeant-style exclamation or name rather than a common-noun lookup; the only near-match, *haxba* "to twist oneself" (< *hax* "to drill/twist"), is a false friend. All three are held open, not forced.

### 9.10 My Little Word Land cross-reference pass

A scan of the My Little Word Land Nahuatl word-list[46] (an informal source, used here for corroboration only, not promotion) against the corpus. Every root below is independently attested in the primary Nahuatl record[10], so the list adds living-Nahuatl support but nothing is committed on its strength alone. No token was promoted to §8 as a result.

| Vaal token / name | Corpus status | Matching list entry | What it supports |
|---|---|---|---|
| Atzoatl | §11.2 | *atzoatl* "dirty water" | the *ā(tl)* + *tzoatl* reading, direct |
| Atziri | committed (§3, §8) | *atzintli* "water [H.]" | the reverential *-tzin* (*ātl* + *-tzin*) |
| Xatlene | §8 committed | *xotlatoc* "it is burning" (*xōtla*) | *xōtla* "to kindle, burn" |
| Eztli Pilli | §9.6 | *piltzintli* "child," *nopilhuan* "my children" | the *-pilli* "noble, child" tail |
| Kuetzakala | §11.3 | *cali* "house" (*calli*) | the *-kala* ~ *calli* "house" tail |
| Ahuatotli, *quiquate* | Text 5, soft | *cua* "I eat," *quicuahtoc* "he is biting him" | *qui-* (3sg obj) + *cua* "eat" |
| Ahuatotli, *tatlat* | Text 5, soft | *tlatla* "burn" (*tlatlatizque*), *tlahtoa* "speak" (*onitlahto*) | both candidate roots; the reading stays ambiguous |
| Ahuatotli, *xictep* | Text 5, soft | *xi-* imperatives, *tepetl* "hill" | the *xi-* "do!" + *tepe-* parse |

The list also confirms the broader Nahuatl frame (*atl* "water," *calli* "house," *coatl* "snake," *tletl* "fire," *miqui* "to die," *tlamanalli* "offering"), consistent with the corpus's Nahuatl layer but adding no new committed token.

**Soft-token sweep.** Running every still-open token against the full list[46] for any root that would close it. The honest result: none closes. Two Ahuatotli tokens gain partial Nahuatl support; the rest find no match, and the Maya softs are out of scope for a Nahuatl source.

| Soft token | Layer | List result | Outcome |
|---|---|---|---|
| Ahuatotli *huatat* | Nahuatl | *cuauh-* "tree, eagle" present (*cuahuitl*, *cuauhtli*) | partial; the reduplicated *-tat* is unexplained, stays soft |
| Ahuatotli *cutlotl* | Nahuatl | *cuitla-* present (*icuitlapan* "behind it") | partial; the fit is loose, stays soft |
| Ahuatotli *xomaplat* | Nahuatl | only *tlapal-* "help, colour" embedded (*tlapalehuia*, *imiazcatlapalhuan*); no *xoma-* | no closure, stays open |
| Ahuatotli *zahua moti* | Nahuatl | no match | stays open |
| Ahuatotli *azcado* | Nahuatl | no *azcatl* "ant" headword in this list | unchanged; the ant reading rests on other Nahuatl sources, not this one |
| Xibaqua *-aqua* | open | no Nahuatl *aqua* form (*atl* "water" is the only water root) | stays open |
| Mektul *ipkaat*, *ka'tse*, *koriek*, *xecwa* | Yucatec / K'iche' | out of scope | Maya tokens; to be checked against Cordemex, not a Nahuatl list |
| Long-standing Maya softs (*cheyel*, *a'tul*, *Axba*, *quxzeh*, *Otsuks*, *ta'*, *fukuur*, *Ma'oxe*, *ukto*) | Yucatec | out of scope | Maya; remain on the Cordemex track |

**Net effect:** no promotion, no closure. Being a Nahuatl pool, the list can only speak to the Nahuatl-side softs (the Ahuatotli set), and there it corroborates two roots without proving either. The Maya-side softs, which are the bulk of the open list, still need the Cordemex and modern-wordlist track.

### 9.11 Dictionary closure pass

A targeted pass over the still-soft tokens, Cordemex first[31][32], then the modern peninsular wordlist[36] where Cordemex gave nothing. Two tokens close; the rest are held, each with its reason.

| Token | Cordemex | Modern wordlist | Outcome |
|---|---|---|---|
| kahk-tche (Mektul) | *k'áak'* "fire," *che'* "tree, wood" | *fuego / lumbre* = *k'áak'*; *árbol / madera* = *che'* | **closed**: *k'áak' che'* "fire-wood, firebrand"; both roots now in §8 |
| quxzeh (Text 4) | *k'ux* "to bite, gnaw; rancor" | *morder* = *k'uux* | **closed at root**: *k'ux* "bite" now in §8; *-zeh* a non-morphemic coda (cf. *Otsuks -s*) |
| xecwa (Mektul) | *xek* only in *hekeb xek* "saddle"; no verb fit | *cortar* = *xoot*; *atacar* = *k'óoch*; no *xec-* | open: *-wa* poss. *waaj* "offering"; *xec-* unresolved |
| ipkaat (Mektul) | no clean *ip-* root | *k'áat* "ask, want" confirmed; no *ip-* | partial: *-kaat* = *k'áat* "ask, want"; *ip-* (poss. *in* "I") unresolved |
| ka'tse-ik (Mektul) | *tse'ek* "sermon, to punish" (poor fit) | *tse* only in *tséel* "side" | partial: *ka'* "two" + *ik'* "wind/spirit" hold; *tse* unresolved |
| ukto (Text 4) | *uk'* "to drink" (noun *uk'ul*) | *ofrenda* = *síih, k'aam* (no fit) | open: nearest is *uk'* "drink" (libation), not clean |
| ta' (Text 3) | *ti'* "to/for"; *taak'* "want" | *para* = *tia'al*; *querer* = *k'áat, óot* | open: two readings logged, neither decisive |
| koriek (Mektul) | not Yucatec (the *r* marks K'iche') | Christenson[47]: re-cut *ko-* "strong, hard" + inchoative (cf. *kowirik*); also *kor-* "loosen," *k'or-* "knock" | soft: leading reading "harden / grow strong"; form not exact, held open |
| cheyel, Axba, a'tul (Text 4) | exhausted earlier in §9.9 | no new fit | open: held as before (Nah. graft / metathesis / *a- + taal*) |

**Result:** two closures (*kahk-tche*, *quxzeh*) and three new committed roots in §8 (*che'*, *k'áak'*, *k'ux*). The rest resist the Yucatec record: most are partial (one attested root plus an unresolved fragment), and *koriek* needs the K'iche' track, which these two dictionaries cannot supply.

**K'iche' follow-up (Christenson[47]).** The two K'iche'-seam items were then run against a dedicated K'iche' dictionary, the project's first (Christenson, compiled from field work in Momostenango and Totonicapán). *jare* is confirmed and upgraded off the phonology-only note[17]: Christenson lists *are'* as the focus pronoun "he, she, it; it is, that is" and *ri* as the article "the," precisely the *are'/ri* family already proposed, so *jare* now rests on a real K'iche' source. *koriek* stays open, but a second pass that does not assume the segmentation *kor-* improves the candidate. The *r* is consistent with K'iche' (which keeps the tap *r* that Yucatec lost and Nahuatl never had). Re-cut as *ko- + -(i)rik*, it lands on the strength field: *ko* "hard, strong, firm" with the inchoative *-(i)rik* "to become X," whose attested realisation is *kowirik* "to become strong, to become hard, to fortify" (also "to freeze")[47]. A boss shouting *koriek!* as a harden-or-strengthen cry fits an attack pool far better than "loosen," so *ko-* "strong" + inchoative is logged as the leading reading, held soft: the dictionary's surface form is *kowirik* (medial *-w-*), and *koriek* would need that *-w-* lost and a *-rik* to *-riek* vowel glide, neither yet shown. The earlier *kor-* "to loosen" (*korobaj*, *koronik*) and a third candidate *k'or-* "to knock, tap" (*k'ork'a'*, *k'orok'ot*) are kept as weaker alternatives, the latter doubly so since its ejective /k'/ should surface in the corpus as *q-* (*qoriek*), not the plain *k-* seen here. The K'iche' sourcing gap is now filled for *jare*; *koriek* is a soft K'iche' token with a candidate parse, the gloss open while the dictionary facts (*ko*, *kowirik*, *kor-*, *k'or-*) stay fixed.

## 10. Lore anchors

- **Atziri**, the vain Vaal queen who sought immortality and eternal beauty ("grace made eternal"), demanding human sacrifice *to* her as "an act of divinity… to transform the world." Her communion with the Beast triggered the Cataclysm that destroyed the Vaal overnight; she lingers afterward in a nightmare realm.
- **The Beast (*pochiti*)**, the primordial entity Atziri communed with; her attempt to merge with it triggered the Cataclysm. In her PoE2 encounter she speaks no Vaal except this single word for it: *pochiti*, best read as "the Hungering One" (Maya *poch* "gluttonous, hungry"), the devourer she feeds. (A Nahuatl *pōchōtl* "ceiba / protector-tree" reading is phonologically possible but has **no** in-game support; see §9.5.)
- **Utzaal (Yutsal)**, Doryani's seat of power and research stronghold (where he pursued immortality, corruption, and time), reachable in PoE2 by travelling to the moments before the Cataclysm. **Not** the capital.
- **Capital / royal seat**, **Lira Vaal**, Atziri's royal temple, was the Vaal capital for much of the empire's history; after its temple burned, **Azala Vaal** (now buried below Sarn) was named the new capital. Atziri's seat is Lira Vaal, where her Temple, and its Commander, appear in PoE2 0.5.0. Utzaal was Doryani's separate domain.
- **Zerphi**, a noble whose autopsy revealed a twenty-year-old's body at age 168, prompting Atziri to set Doryani researching his longevity. "Undying" in legend, though he died.
- **Cuachic Vault**, a PoE2 0.5.0 interlude area holding surviving Vaal. Its bosses are the sibling Blood Priestess **Zelina** (who sings the litany's call) and Blood Priest **Zolin** (the response). Doryani's pass-phrase, "the time of the sparrow has come," is rejected on sight: Zolin emerges with "What nonsense do you speak?" and Zelina with "What do you ramble about?", and they attack rather than parley.
- **Cuachic = the Shorn Ones.** *Cuachic* is attested Classical Nahuatl. The *cuāchicqueh* ("shorn ones") were the most prestigious Aztec warrior society: heads shaved but for a braid over the left ear, faces painted half blue and half red, sworn never to step backward in battle on pain of death. So the Blood Priests are an elite Vaal warrior-priest order, which is why they fight to the death rather than heed a passphrase, and why Zolin's barks run to "We stand the test of time," "No sacrifice is too great," and "Cuachic maneuvere!" It plants a second attested Nahuatl military term beside the *xefe* ("commander") register of Text 3.
- **The sibling blood-pact (from the English barks).** Zolin sustains himself by draining Zelina, "We live for one another," "Loyal transfusion," "Pact… of blood", and each rages at the other's fall ("I will avenge you, sister!"; "No! Zolin! You will suffer for this!"). Zelina brands the player a "foul Outlander." Her enrage line names a Vaal tome, the **"Tome of Guatelitzi"**, now identified as *Guatelitzi, Architect of Flesh*, the Vaal flesh-and-immortality architect of the Temple of Atzoatl (§9.8).
- **Eztli Pilli**, an in-game Vaal tome of forbidden, volatile knowledge, "too dangerous to use." Its title is Classical Nahuatl *eztli* "blood" + *pilli* "noble, prince" = "the Blood Prince" (see §9.6), a fitting name for a grimoire of Vaal blood-magic, and a second Vaal *tome* alongside the *Guatelitzi*.
- **The invader / "Demon of Atzoatl"**, the **Temple of Atzoatl** was the PoE1 Incursion temple, repeatedly raided by the Exile ("Godslayer") ~20 years before PoE2 to kill its architects. In PoE2 the Vaal mistake the player for that demon. The Commander's *u'tra buxa*, now read as *u'tra ba'ax* "another such thing / another one" (see §9.4), most likely points at this returning intruder, though the temple he defends is Atziri's at Lira Vaal, not Atzoatl.
- **Naming consistency**, the surrounding Vaal proper names (Cuachic, Ketzuli, Napuatzi, Atzoatl) are uniformly Nahuatl-flavored, consistent with the Nahuatl layer identified above.

---

## 11. Vaal and Vaal-related figures

The same attested-root method, applied to the proper names of Vaal and Vaal-adjacent figures. The useful result is the sorting: a few names carry live Maya or Nahuatl roots, a few are opaque to the palette, and a few are clearly borrowed from outside it. Forcing Nahuatl onto every Vaal name would be a mistake; this section shows where it fits and where it does not.

### 11.1 Xibaqua, the first Vaal

**Lore.** *Xibaqua* was a historical Vaal figure whose remains were held to be the **progenitor of all Vaal**, "born from the flesh of ancient Vaal gods." The origin myth runs: *"Xibaqua's treachery was met with divine fury. One by one, the gods reclaimed their flesh, until all that remained was a droplet of pure light: the first Vaal."*[39]

**Root, *Xib-*.** Two attested Maya readings, both on theme, are logged rather than chosen:
- Yucatec *xiib* "male, man"[36], i.e. "the man / the first man", a plain fit for a progenitor.
- K'iche' *xib'* "fear," the root of **Xibalba**, the Maya underworld ("place of fear")[17], fitting a being drawn from the gods' flesh, and resonant with the Vaal fear-cosmology (cf. *Yugul*, who held fear the "bedrock of the cosmos," §11.3). It also lands on the **K'iche' seam** already opened by *jare* (§9.2), the one place Highland Maya surfaces.

**Tail, *-aqua*.** Open: possibly Nahuatl *ā(tl)* "water" (the *atl* of *Atziri* and *Atzoatl*), possibly just a name-ending. **Status:** *Xib-* attested (two readings kept); *-aqua* open.

### 11.2 Atzoatl, the temple

**Lore.** The **Temple of Atzoatl**, a Vaal treasure-temple of many pursuits (immortality, corruption, weather-control, sacrifice), built late in Atziri's reign and made her final seat; the present-day Vaal take the player for its "demon" (§10).[40]

**Root.** Nahuatl, built on *ātl* "water"[10] (the root behind *Atziri*, *ātl* + reverential *-tzin*, a form the same list independently carries as *atzintli* "water [H.]") compounded with *tzoatl* "dirty water, slops." *Tzoatl* is itself an attested Nahuatl word: Molina 1571 glosses it "lauazas, o lauaduras" (dishwater, washings), recorded in the Wired Humanities dictionary[10]. *Atzoatl* therefore reads as "dirty / fouled water," apt for a temple given over to corruption and blood-sacrifice (§10). This **resolves the medial *-tzo-*** left open before: it is not a weak *tzotl* "grime" guess but the attested compound *a(tl)* + *tzoatl*. The same gloss is listed directly in a community Nahuatl word-list, which renders *atzoatl* as "dirty water"[46]; that list is an informal primary source, recorded here only because Molina independently confirms it via [10]. **Status:** *ātl* + *tzoatl* "dirty water" attested; medial resolved. Consistent with the Nahuatl place-name layer (*-tlān* in *Teoyuxtlane*, the *cua-* of *Cuachic*).

### 11.3 Vaal gods

The palette test, name by name. Only two carry live Nahuatl roots; the rest are opaque or out-of-palette, and are marked as such rather than forced.

| Figure | Lore | Name analysis | Verdict |
|---|---|---|---|
| Kuetzakala | a Vaal-related divine name; reported (PoE2, via Doryani) as a "goddess of the siege," not independently verified here | Nahuatl *quetzal(li)* "quetzal-plume; precious"[10] (root of *Quetzalcoatl*) + *-kala* poss. *calli* "house, structure"[10] | Nahuatl root attested; tail soft |
| Yaomac | ancient Vaal god, three serpent heads, shepherd of Vaal souls[41] | Nahuatl *yāō(tl)* "war, enemy" + *-mac* "in the hands of" (locative of *māitl* "hand")[10] → "in the hands of war" | clean Nahuatl parse |
| Kamasa | a Vaal god; the Kamasan Smith (Text 5) is "of Kamasa"[42] | poss. K'iche' *Camazotz*, the Popol Vuh death-bat (*kame* "death" + *sotz'* "bat")[45] | Maya / K'iche' lead, soft at the derivation |
| Kopec | a Vaal god, little known, with a temple[42] | no transparent root; a *-pec* ~ Nahuatl *-tepec* "place of" link drops the *te-* and stays weak; the "sun god / Xipe Totec" tie is thematic only | opaque (weak guess logged) |
| Yugul | "Reflection of Terror," a fear-scholar who ascended to godhood[41] | reading the medial */g/* as a stylised consonant (the corpus's /g/ convention, §2.3): Yucatec *yuk* "to shake, agitate, set trembling" (*agitar, menear*[36]), the bodily sign of terror, tail *-ul / -kul* open; an alternative folds the medial into Maya *k'u* "god, sacred" (Cordemex *maban k'u* "atheist," *k'u na* "temple"[31]; modern *k'uh*[36]), *yu(k)* + *k'u(l)* "the divine one," fitting an ascended god. The earlier "fear" gloss is set aside (Yucatec "fear" = *sahkil*[36]) | ○ soft (was opaque): root candidate(s) attested, segmentation open |
| Apep | a serpent-deity of Vaal chaos / poison (items *Apep's Supremacy*, *Apep's Slumber*) | **Egyptian** *Apep / Apophis*, the chaos-serpent[45] | borrowed from outside the palette |
| Ralakesh | "Master of a Million Faces," a mind-control Vaal god[41] | Sanskrit *Rākṣasa*, the shape-shifting illusion-demons, fitting the "million faces"[45] | outside the palette |
| Arakaali | "Spinner of Shadows," an ancient (pre-Vaal) spider goddess | a blend of Greek *Arachne* "spider" and Hindu *Kālī* (death, time)[45] | outside the palette |

The sorting is the point, and a fresh comparative pass, cross-checked here against the dictionaries, sharpened it. *Yaomac* now parses cleanly, *yāō-* "war" + *-mac* "in the hands of," and *Kuetzakala* sits firmly on *quetzal-*. *Kamasa* gains a real Maya lead in *Camazotz*, the Popol Vuh death-bat, which also ties it to the Xibalba theme behind *Xibaqua* (§11.1). *Kopec* stays opaque (its *-pec* drops the *te-* of *-tepec*, and the link stays weak). *Yugul* now carries a soft reading: with the medial */g/* read as a stylised consonant (§2.3), it resolves to Yucatec *yuk* "to shake, set trembling"[36], the bodily sign of terror, with the tail *-ul / -kul* open, or alternatively folds the medial into Maya *k'u* "god"[31][36] for an ascended-god reading; the earlier "fear" gloss is set aside, since Yucatec "fear" is *sahkil*[36]. The three outliers pin down to specific foreign sources, Egyptian *Apophis*, Sanskrit *Rākṣasa*, and a Greek *Arachne* plus Hindu *Kālī* blend, the same caution the */d/* and */r/* tests enforce (§2.3).

### 11.4 The Architects of Atzoatl

The Architects of Atzoatl were the Vaal master-builders and specialists, each governing one domain of the Temple of Atzoatl[43]. Their names are uniformly Nahuatl-styled, the *-tl / -tli / -atl* absolutive endings dominate, with a handful of Maya-rooted exceptions; only *Guatelitzi* (Flesh, §9.8) has been carried to a committed reading. The roles below are the in-game, lore-attested functions; conjectural readings of the lore are omitted. The name-root column uses the same standard as the rest of the corpus: an attested root with a workable phonology is marked ○ soft, a name with no isolable root is marked opaque, and a fully worked name is marked ●. Per-architect wiki pages branch from the *Incursion room* roster hub[43]; the lore was compiled by the community in a single reference post[48].

| Architect | Domain | Role (lore-attested) | Name roots |
|---|---|---|---|
| Ahuana | Ceremonies | Oversaw the Vaal's mass human sacrifices; in Incursion, sacrifices unique items to create others. | ○ poss. Nahuatl *ahua-* (*ahuatl* "oak, thorn")[46]; *-na* tail open; soft-to-opaque |
| Guatelitzi | Flesh | Directed life-force transferral and the study of immortality; also produced powerful prosthetics. | ● Nahuatl *cuauh-* "tree, eagle" (*Gua-* = /kʷ/) + reverential *-tzin* (§9.8)[38] |
| Atmohua | Iron | Crafted the Vaal's armours. | *at(l)-* "water"? + *-mohua* open; opaque |
| Cholotl | War | A military commander; gathered the most war-driven Vaal. | ○ *-tl* absolutive + *choloa* "to flee, leap"[10] candidate |
| Ticaba | Arena | Held gladiator bouts and ritual combat. | opaque |
| Azcapa | Guild | A jeweller who made gold trinkets and baubles for Atziri. | ○ Nahuatl *āzcatl* "ant"[10] + locative *-pa(n)* "at" (cf. *Azcapotzalco*) |
| Estazunti | Vault | Stored and catalogued the gifts sent to Atziri. | opaque (only a *-tzin*-like tail) |
| Juatalotli | Hoard | Gathered and preserved Vaal relics and culture. | ○ *Jua-*/*Gua-* onset = Nahuatl /kʷ/ (§2.3) + *-otli* absolutive; root open |
| Puhuarte | Forge | A smith; his fire-craft is later weaponised by the Omnitect. | opaque |
| Zantipi | Concealment | Built strongboxes and hidden passages. | opaque |
| Hayoxi | Destruction | Made explosives. | ○ Yucatec *haay* "to raze, level"[31] (a Maya root in a Nahuatl-styled set); *-oxi* open |
| Matatl | Fortifications | Master trap-builder and architect. | ○ Nahuatl *matlatl* "net, snare"[10] (*-tl* absolutive), apt for traps |
| Xopec | Power | Studied electricity. | opaque (*-pec* parallels *Kopec*; the *-tepec* link stays weak, §11.3) |
| Paquate | Corruption | Master of concentrating corruption; "Paquate's Mechanism" drives Jiquani's Sanctum. | *paqui* "to be glad"[46] candidate + *-te* open; opaque-leaning |
| Zalatl | Thaumaturgy | Oversaw virtue-gem work; a student of Doryani. | ○ *-tl* absolutive; root (*zal-* / *tzalan*?) open |
| Citaqualotl | Swarm | Created metallic insect monsters. | ○ *-tl* absolutive + *cua/qua* "to eat" (*cualo* "be eaten")[10] candidate |
| Jiquani | Industry | Built soul-core constructs at the Utzaal machinarium; his constructs helped excavate the Cuachic Vault. | opaque (/g/-class *Ji-* onset) |
| Opiloti | Strife | Researched Timeless Monoliths ("Obelisks Beyond Time"). | opaque (*-ti* tail) |
| Tacati | Toxins | Worked plant- and snake-based poisons; venerates the serpent Apep. | opaque (*-ti* tail; *tlāca-*? open) |
| Topotante | Storms | Built "spires" that altered the weather. | opaque |
| Zilquapa | Breach | Studied or worshipped the Breach (Cult of the Purple Flame). | opaque (poss. *-qua-* /kʷ/ + locative *-pa*) |
| Quipolatl | Nexus | Proposed and designed the Temple of Atzoatl. | ○ *-atl* absolutive (shared with *Atzoatl*); *poloa* "to lose, destroy"[10] candidate |
| Tzamoto | Torments | Imprisoned and tortured those who disobeyed Atziri. | ○ *tzacua* "to close, imprison"[10] candidate, apt for torment; *-moto* tail (cf. *Uromoti*) |
| Uromoti | Expansion | Ran exploration and city-planning; built the Cuachic Vault shelter with Jiquani; drew maps of fictional lands. | opaque (*-moti* tail, cf. *Tzamoto*) |
| Xipocado | Royal Architect | Rebuilt Lira Vaal; mini-boss of *Fate of the Vaal*; spied on Doryani. | ○ Nahuatl *Xīpe* (Totec, "the Flayed One")[10] candidate; *-cado* open |

Four further figures sit beside the temple roster:

| Figure | Domain | Role (lore-attested) | Name roots |
|---|---|---|---|
| Vaal Omnitect | Construct atop Atzoatl | A construct in the temple's top chamber. | not Mesoamerican: Latin *omni-* "all" + *-tect* (from *architect*), "all-builder" |
| Ketzuli | Time / High Priest of the Sun | Oversaw the solar-powered time machine at Utzaal; later turned Undying. | ○ Nahuatl *quetzal(li)* "quetzal-plume, precious"[10] (cf. *Kuetzakala*, §11.3); tail open |
| Mahuxotl | Banished Architect | Known only from his unique shield; the reason for his banishment is unrecorded. | ○ *-xotl* ending (cf. *Xōlotl*); *mahui* "to fear"[10] candidate |
| Ahuatotli, the Blind | Vaal Outpost Delve boss | Dressed as an architect, inhabits "The Grand Architect's Temple," speaks short Vaal lines (Text 5). | ○ Nahuatl *ahua-* "oak, thorn"[46] + *tototl* "bird"[10] (§7) |

## 12. Method notes

- **Geographic-palette principle.** Prefer attested Maya/Nahuatl roots over cross-family guesses (Quechua, Polynesian, Taíno, Tagalog); reject any root that needs invented grammar. Applied late to swap out the four guesses in §9.3 and to reject unverifiable items (*máax* "crush," *óoxol* "heat," *ma'ax* "not even").
- **Candidate source pools beyond the core three.**[19][24] When a token resists the Yucatec / Nahuatl / K'iche' palette, two adjacent pools are worth testing before defaulting to a loan. **Xinkan (Xinca)** is a small, now-extinct non-Mayan family of southeastern Guatemala with no demonstrated affiliation but heavy Mayan-loan contact; it abuts the Highland-Maya seam, so it is a natural next stop for a stubborn root, with one caveat: some Xinkan languages carry voiced stops (*b, d*) and ejectives, so a Xinkan source would blur the clean /d/ = Spanish reading of §2.3 and must be weighed against it, not used to wave it away. The wider **Aztecan (Nahuan)** branch of Uto-Aztecan runs, loosely, from the western U.S. down into Central America (the Mesoamerican-languages literature stretches the span from roughly Oregon to Panama); beyond Classical Nahuatl this includes **Pipil / Nawat** of El Salvador, geographically apt for a Vaal read as a Central-American creole. Both are recorded as places to look, not committed layers, anything drawn from them must still clear the attested-root test.

 **Result of the Xinkan / Nahuan cross-check.** Run against attested Xinka vocabulary,[26] the committed lexicon turns up no cleaner fit: Xinka core words (*uy* "water," *ura* "fire," *parri* "sun," *tz'uona* "black," *mowa* "white") match no Vaal token, so nothing committed needs revising. Two points are recorded honestly rather than acted on: (a) the zone's other families were run against both anomalies and neither moved, for *jare*, Aztecan has no native /r/ at all and its demonstratives (*inin / inon*, *in*) show none,[27] while Xinka has a tap /r/ but only a third-person *nah* demonstrative,[26] so K'iche' *are' / ri* stays the fit; for *daka*, Aztecan *maca / maka* "to give" matches the imperative slot's sense but not the /d/ onset, and Xinka's native /d/ comes with no attested *daka*-like "give" verb, so Spanish *daca* keeps the form; (b) the living Nahuan branch **Pipil / Nawat** of El Salvador corroborates a Nahuatl stratum this far south but supplies the same roots as Classical Nahuatl, confirming geography without displacing a reading. The one open token the zone's languages *did* resolve is *Guatelitzi* (§9.8), via the Nahuatl tree-root behind *Guatemala*.
- **Living modern reflexes as corroboration.** Several of these roots survive in modern Latin-American Spanish, giving a second, independent attestation channel, especially useful as a fallback or tiebreaker when the classical dictionaries are thin. *poch* "gluttonous, hungry" is carried into Mexican Spanish and listed by the RAE (→ *pochiti*); Nahuatl *chantli* "home" lives on as *chante* "house" (→ *i'chian*); Nahuatl *pōchōtl* "ceiba" survives as *pochote*, and colloquial *pochotón* "husky, thick-built" preserves the tree's "big, sturdy" sense (→ the *pochiti* co-reading). The channel is not limited to Spanish: within living **Maya** itself, *poch* "eager, craving" is still everyday Yucatec, a Belize Yucatec community word-list records *poch* "anxious, eager" (*poch de comer* "craving to eat"), a native-speaker witness that the *poch* "Hungering One" reading rests on a word the core layer never lost.[30] When nothing in the classical sources settles a token, a surviving regional reflex can confirm both the root and its semantic range.[8,22]
- **Uniform directionality.** All three texts are offerings flowing up to Atziri, she receives and consumes; the worshippers give themselves.
- **"Alien" letters as evidence.** The /g/ and /r/ that do not fit the Yucatec-plus-Nahuatl core each revealed an additional source (Nahuatl *yancuic*; K'iche'); the /f/ revealed the Romance seam.
- **Cross-graft morphology.** The creole freely puts Nahuatl affixes on Maya roots (*qexcan* = Maya *k'ex* + Nah. *-can*; *pochiti* = Maya *poch* + Nah. inchoative *-ti*), a structural signature worth using when parsing new tokens.

---

## 13. Status

All four texts are documented. Texts 1–2 are closed, their last soft tokens (*Ma'oxe*, *jare*) are resolved, all candidates preserved above, and the anomalous sounds accounted for as evidence of a multi-source conlang. Text 3, **Quemalani, the Elite Commander** (§5), contributes a five-line corpus with committed content tokens (folded into §8) and several flagged soft tokens (§9.4). Text 4, the **Drill Sergeant & Vaal Regiment** drill (§6), adds a fixed call-and-response built on committed roots (*Otsuks! … U'te mucane!*), its soft tokens (*a'tul*, *cheyel*, *Axba*, *quxzeh*, *Kíibsa'*) and full token analysis tracked in §9.9; none is promoted to §8 yet. Text 5 (§7) opens a stray-capture log for one-off NPC lines; its first entry, the Kamasan Smith's *Ti ek tala jare'yantul!*, parses fully on committed roots and adds *tala* "to come" to the lexicon.

**Texts 1 & 2 are source-validated against the game files.** Text 1 is the datamined `VaalSermon_01`–`08`; Text 2's sixteen lines match both Cuachic Vault bosses' chant pools exactly, with zero drift, and the speaker roles are fixed, **Zelina** (Priestess) sings the call, **Zolin** (Priest) the response. *Ma'oxe* is confirmed verbatim.

**Open / optional for the future:** if more written Vaal surfaces, run the same phoneme-to-root method and extend this shared lexicon. The remaining open items are narrow: the exact K'iche' lemma behind *jare'* (its apostrophe form now attested in Text 5); the unadopted *Ma'oxe* alternates; *fukuur*'s phonetic fit (*fulgor* adopted but soft); *ta'* (*ti'* vs *taak*); and the unidentified *ukto* in the Text 4 catechism (§9.7). *Guatelitzi* has left the open list: it is an attested in-game proper name, *Guatelitzi, Architect of Flesh* of the Temple of Atzoatl, now carried in §8 (§9.8). Two former holdouts now have leading candidates that break no rule: *buxa* ← *ba'ax* "what / what-thing" (keeps *x* = /ʃ/ intact) and *Eche lu* ← Spanish *échelo* "pour/cast it out" (supplies the *ch* /tʃ/ that *he'ela'* could not). Both sit in §9.4.

---

## 14. Citations

*Numbered to match the bracketed markers in §§2–12 and the **Source** column of §8. APA 7th style; every entry carries a working URL (FAMSI and Wired Humanities are word-searchable, so any root can be confirmed by lookup). Print works are marked. Candidate parses raised in collaboration (including external-model suggestions) were adopted only after verification against these sources.*

**Primary Vaal text & game data**

1. poe2db. (n.d.). *Xolotl, the Royal Commander* (in-game name *Quemalani, the Elite Commander*; internal asset *BlackjawPastLiving*) [Vaal "Text Audio" voice lines]. Retrieved June 16, 2026, from https://poe2db.tw/us/Xolotl%2C_The_Royal_Commander
2. poe2db. (n.d.). *Zolin, Blood Priest* [Vaal "Text Audio"]. Retrieved June 16, 2026, from https://poe2db.tw/us/Zolin%2C_Blood_Priest#ZolinBloodPriestTextAudio
3. poe2db. (n.d.). *Zelina, Blood Priestess* [Vaal "Text Audio"]. Retrieved June 16, 2026, from https://poe2db.tw/us/Zelina%2C_Blood_Priestess#ZelinaBloodPriestessTextAudio
4. LocalIdentity. (2025). *poe2-data* [Data set: NPCTextAudio.json, English & French]. GitHub. https://github.com/LocalIdentity/poe2-data
5. Path of Exile 2 Wiki (Fextralife). (n.d.). *Fate of the Vaal*; *Recruit the Vaal*; *The Cuachic Vault*; *Atziri's Temple*. Retrieved June 16, 2026, from https://pathofexile2.wiki.fextralife.com/Fate+of+the+Vaal, https://pathofexile2.wiki.fextralife.com/Recruit+the+Vaal, https://pathofexile2.wiki.fextralife.com/The+Cuachic+Vault, https://pathofexile2.wiki.fextralife.com/Atziri's+Temple . Path of Exile Wiki. (n.d.). *Atziri, Queen of the Vaal*; *The Temple of Atzoatl*; *The Vaal*. https://www.poewiki.net/wiki/Atziri,_Queen_of_the_Vaal, https://www.poewiki.net/wiki/The_Temple_of_Atzoatl, https://www.poewiki.net/wiki/The_Vaal
6. Grinding Gear Games. (2024–2026). *Path of Exile 2* [Video game; in-game dialogue and item text]., *pochiti* (poe2db: *Atziri, the Red Queen*, https://poe2db.tw/us/Atziri%2C_the_Red_Queen); the *Eztli Pilli* tome; the Blood Priests' English barks; the *Quemalani* chat-feed lines.

**Yucatec Maya**

7. Bolles, D. (2001). *Combined dictionary–concordance of the Yucatecan Mayan language*. Foundation for the Advancement of Mesoamerican Studies. http://www.famsi.org/reports/96072/index.html, searchable online. Print companion: Barrera Vásquez, A., Bastarrachea Manzano, J. R., & Brito Sansores, W. (1980). *Diccionario maya Cordemex: Maya-español, español-maya*. Ediciones Cordemex. [Yucatec roots: *ik', ba', iitz, kuxtal, kíimil, il, uk', kutz, sak, ha', muk', náach, ich, lu'um, tul, el, ts'ook, k'ex, xul, yax, akal, anaab, k'i'ik', ki', pox*; the *-x* interrogatives.]
8. Real Academia Española. (n.d.). *Poch*. In *Diccionario de la lengua española*. Retrieved June 16, 2026, from https://dle.rae.es/poch
9. Encyclopædia Britannica. (n.d.). *Yucatec language*. Retrieved June 16, 2026, from https://www.britannica.com/topic/Yucatec-language

**Classical Nahuatl**

10. Wired Humanities Projects. (n.d.). *Nahuatl dictionary*. University of Oregon. https://nahuatl.wired-humanities.org/, per-word entries: *eztli* (https://nahuatl.wired-humanities.org/content/eztli), *pilli* (https://nahuatl.wired-humanities.org/content/pilli), *pochotl* (https://nahuatl.wired-humanities.org/content/pochotl), *chantli* (https://nahuatl.wired-humanities.org/content/chantli), *yocoya* (https://nahuatl.wired-humanities.org/content/yocoya); also *atl, teōtl, cualli, nochi, yancuic, aocmo, tlapechtli, tlayohua, mochi*; the attested collocation *huey pilli, cualli eztli*.
11. Gran Diccionario Náhuatl. (2012). Universidad Nacional Autónoma de México. *Pochotl*. https://gdn.iib.unam.mx/diccionario/pochotl/175246, ceiba; protector-ruler metaphor.
12. Wiktionary. (n.d.). *pochotl*; *teotl*; *yancuic*; *waaj*. https://en.wiktionary.org/wiki/pochotl, https://en.wiktionary.org/wiki/teotl, https://en.wiktionary.org/wiki/yancuic, https://en.wiktionary.org/wiki/waaj
13. Wikipedia. (n.d.). *Teotl*. Retrieved June 16, 2026, from https://en.wikipedia.org/wiki/Teotl
14. Wired Humanities Projects. (n.d.). *Ti* (suffix) & *Tlan*. In *Nahuatl dictionary*. https://nahuatl.wired-humanities.org/content/ti, https://nahuatl.wired-humanities.org/content/tlan, the inchoative *-ti* and locative *-tlan*.
15. SIL México. (n.d.). *Consonantes del náhuatl*. Instituto Lingüístico de Verano. https://mexico.sil.org/es/lengua_cultura/nahuatl/consonantes-del-nahuatl, Nahuatl phonology (*b, d, g, f, ñ, rr* loan-only; *tl*, *kʷ*; *w*→[v~f]).
16. Wikipedia. (n.d.). *Aztec warfare* (the *cuāchicqueh*, "shorn ones"). Retrieved June 16, 2026, from https://en.wikipedia.org/wiki/Aztec_warfare

**K'iche' / wider Mayan family**

17. Wikipedia. (n.d.). *K'iche' language*. Retrieved June 16, 2026, from https://en.wikipedia.org/wiki/K%27iche%27_language, phonology (implosive *ɓ*, tap *r*, no voiced stops; dialectal [ð] for /l/); the *are'/ri* demonstratives behind *jare*.
18. Bennett, R. (2016). Mayan phonology. *Language and Linguistics Compass, 10*(10). Open-access PDF: https://bpb-us-w2.wpmucdn.com/campuspress.yale.edu/dist/c/1125/files/2015/09/Bennett2015_Mayan_phonology-2hbkyox.pdf, Mayan consonant inventories; the uvular *q*.
19. Encyclopædia Britannica. (n.d.). *Mesoamerican Indian languages*. Retrieved June 16, 2026, from https://www.britannica.com/topic/Mesoamerican-Indian-languages, uvular *q* in the K'ichean-Mamean / Q'anjob'alan branches; the family's geographic span.

**Spanish / Romance**

20. Real Academia Española. (n.d.). *Daca*. In *Diccionario de la lengua española*. Retrieved June 16, 2026, from https://dle.rae.es/daca, "Da, o dame, acá" (recorded since the *Diccionario de autoridades*, 1732).
21. Wiktionary. (n.d.). *echar*; *fulgor*. https://es.wiktionary.org/wiki/echar, https://es.wiktionary.org/wiki/fulgor, *échelo* (← Lat. *iactare*); *fulgor* (← Lat. *fulgur*); also *otra* (→ *u'tra*), *jefe* (archaic *xefe*), *ascensión*.
22. Diccionario del español de México. (n.d.). *Chante*. El Colegio de México. https://dem.colmex.mx/ (s.v. *chante*, ← Nahuatl *chantli*). For *pochotón* (Costa Rican usage; ← *pochote* ← Nahuatl *pochotl*): Ecija. (n.d.). *Tico expressions (costarriqueñismos) 4*. https://www.ecija.com/en/news-and-insights/tico-expressions-costarriquenismos-4/

**Datamining tool**

23. SnosMe. (n.d.). *poe-dat-viewer* [Computer software]. GitHub. https://github.com/SnosMe/poe-dat-viewer, browser reader for PoE2 *.datc64* tables; route to current *NPCTextAudio* data.

**Candidate source pools (exploratory; §12)**

24. Encyclopædia Britannica. (n.d.). *Xinca language*. https://britannica.com/topic/Xinca-language ; Wikipedia. (n.d.). *Xincan languages*. https://en.wikipedia.org/wiki/Xincan_languages, the non-Mayan Xinkan family of southeastern Guatemala (Mayan-loan contact; some varieties carry voiced *b, d*).
25. *Guatemala* (toponymy). New World Encyclopedia. (n.d.). *Guatemala*. https://www.newworldencyclopedia.org/entry/Guatemala ; Wikipedia. (n.d.). *K'iche' people*. https://en.wikipedia.org/wiki/K%CA%BCiche%CA%BC_people, Nahuatl *Cuauhtēmallān* "place of many trees" (*cuahui(tl)* "tree" + *tema* "to fill" + *-tlan* "place"), the calque of K'iche' *k'iche'* "many trees"; the *cuauh-* "tree" root behind *Guate-* (cf. *Cuauhtémoc* → *Guatemoc*).
26. Xinka lexicon. Native Languages of the Americas. (n.d.). *Xinca words* (Chiquimulilla Xinka). http://www.native-languages.org/xinca_words.htm ; Rogers, C., & Sachse, F. (2025). Xinkan and Lencan. In S. Wichmann (Ed.), *The Languages and Linguistics of Mexico and Northern Central America: A Comprehensive Guide* (pp. 775–814). De Gruyter Mouton. https://doi.org/10.1515/9783110421705-017 (drawing on Sachse 2010, ~1300-item Xinka vocabulary), basic Xinka forms used for the cross-check (§9.8, §12).
27. Aztecan lexical & grammatical data (cross-check; §9.2, §9.4, §9.9, §12). Mexica.Net. (n.d.). *Nahuatl–English online dictionary*. https://www.mexica.net/dictionary/, *maca* "to give"; the demonstratives *inin* "this," *inon* "that." Wired Humanities Projects. (n.d.). *namaca* (*na-* + *maca*). https://nahuatl.wired-humanities.org/content/namaca . The absence of a native /r/ in Nahuatl, and so across the Nahuan branch, incl. Nawat, per [15].
28. Yucatec Maya verbal morphology (for the §9.9 root-search). Blair, R. W., & Vermont-Salas, R. (1965–1967). *Spoken (Yucatec) Maya*. University of Chicago [Chicago "Digital Maya"]. https://lucy.lib.uchicago.edu/, *kuxtal* as a stative / positional verb. The Yucatec causative *-s* and verbal-adjective *-kun(s)* (e.g. *séebkuns* "make quick"): parryc.com, *Yucatec Maya* grammar (citing Gorostieta). https://parryc.com/language/yucatec-maya . That *d, f, g, j, r, v* are non-native to Yucatec: https://www.mustgo.com/worldlanguages/yucatec/ . Standard reference work: Bricker, V. R., Po'ot Yah, E., & Dzul de Po'ot, O. (1998). *A Dictionary of the Maya Language as Spoken in Hocabá, Yucatán*. University of Utah Press.
29. Mesoamerican military lexicon (for the §9.9 *Otsuks* semantic search). Nahuatl *yāōquīzqui* "soldier": Wired Humanities Projects, citing Molina (1571). https://nahuatl.wired-humanities.org/content/yaoquizqui . Nahuatl *tiacāuh* "valiant man / warrior": Wired Humanities, citing Sahagún, *Florentine Codex*, Bk 10. https://nahuatl.wired-humanities.org/content/tiacauh . The *Otōntin* (Otomi) and *Cuāchicqueh* ("Shorn Ones") warrior societies: Wikipedia, *Aztec warfare*. https://en.wikipedia.org/wiki/Aztec_warfare . K'iche' *achi* "man," *ajlab'al* "warrior" (*lab'al* "war"): Kaufman, T. (2003), *A Preliminary Mayan Etymological Dictionary* (FAMSI). Yucatec *holkan* "soldier," *ba'ate'el* "warrior/fight": Barrera Vásquez, A. (1980), *Diccionario Maya Cordemex*.
30. Yucatec Maya (Belize) heritage word-list, native-speaker community attestation, used as living corroboration (not a primary dictionary). Institute of Archaeology (NICH), Belize. (n.d.). *A list of 100 Yucatec Maya words and their English translation* [Facebook post; compiled by Andy Chuc of To'one Masehualo'on, San Pablo, Orange Walk]. https://www.facebook.com/IABelizeNICH/posts/a-list-of-100-yucatec-maya-words-and-their-english-translation/10159657738759966/, records *poch* "anxious, eager" (*poch de comer* "craving to eat"), *he'la'* "here it is / tenga," and *ta'* "excrement."
31. Yucatec *tsuk* "group, cluster, bunch" (root for *Otsuks*, §9.9). Barrera Vásquez, A. (1980). *Diccionario Maya Cordemex*, s.v. *tzuc / tsuk* ("buche o panza de los animales; cresta o mechón; grupo de árboles pequeños, montecillo") **and s.v. *much'***, where *tsuk* is listed as a synonym glossed *"montón de granos o cosas menudas,"* used as a **numeral classifier** in the frame *hun tsuk* "one cluster/heap," *ka' tsuk* "two," with *tsuk-en-tsuk* "in clusters." **Now verified directly in the Cordemex text** (the *Diccionario Maya Cordemex* citation-preview, consulted in full from the local HTML copy added to the project, preview at https://dokumen.pub/diccionario-maya-cordemex-maya-espaol-espaol-maya.html ; complete PDF at https://filosofiamaya.com/wp-content/uploads/2024/04/03_yuc_diccionario-maya-cordemex.pdf [32]), superseding the earlier dependence on a secondary Cordemex-phonetic transcription (*Apellidos mayas y sus significados*, México Desconocido, https://www.mexicodesconocido.com.mx/apellidos-mayas-significados-nombres-maya.html), which is retained only as corroboration. The classifier sense is decisive: a form that literally counts *groups* is the most natural source for a unit-call.

**Maya-language dictionary repository (source-of-sources; §9.9, §12)**

32. Filosofía Maya. (2021, July 31; updated 2026-01-14). *Diccionarios de las lenguas mayas.* https://filosofiamaya.com/2021/07/31/diccionarios-de-lenguas-mayas/, direct-download PDFs of thirteen Maya dictionaries, including the **complete** *Diccionario Maya Cordemex* (Barrera Vásquez 1980; https://filosofiamaya.com/wp-content/uploads/2024/04/03_yuc_diccionario-maya-cordemex.pdf, the full text behind the partial dokumen.pub preview used for [31]); the colonial *Calepino de Motul* (Acuña 2001) and *Bocabulario de Maya Than* (Acuña 1993); Bolles' *Combined Vocabularies* (2010); the *Diccionario Maya Popular* (2007); Bricker, Po'ot Yah & Dzul de Po'ot's *Hocabá* (1998); INEA (1998); and, for the conlang's non-Yucatec layers, Itzaj (Hofling & Tesucún 2000), Mopan (Hofling 2011), Lacandón (Hofling 2014), and two Ch'orti' dictionaries (Pérez Martínez et al. 1996; Hull 2016). The repository carries **no K'iche' dictionary**, so the K'iche' seam ([17]) still sources separately. A catalogued index with per-source relevance notes is kept beside this document as *Maya_Dictionary_Sources.md*.

33. New roots for the §9.9 Text 4 upgrades. **Nahuatl *chiya / chīa* "to wait, await, watch for, observe"** (the sentinel verb behind *cheyel*): Wired Humanities Projects, *Nahuatl dictionary*, s.v. *chiya* (citing Molina 1571; Lockhart 2001; Launey & MacKay 2011). https://nahuatl.wired-humanities.org/content/chiya . **Yucatec *k'ux* "to bite, gnaw; ache; rancor, anger"** (the root behind *quxzeh*, ejective per the corpus's *q* = /k'/, cf. *qexcan* ← *k'ex*): Barrera Vásquez, A. (1980), *Diccionario Maya Cordemex*, s.v. *k'ux* (*k'uxuk* "doler"; *k'uxil* "rencor, coraje"), verified directly in the project copy; full PDF via [32].

34. Nahuatl exclamatory / presentative particle *o* (the onset of *Otsuks*, §9.9). Wired Humanities Projects, *Nahuatl dictionary*, s.v. *o*, Molina (1571): *o* "es señal de optativo, y también de los pretéritos, e interjección del que está afligido y hace exclamación," and *o* "*he aquí*. adverbio." https://nahuatl.wired-humanities.org/content/o-0
35. Maya orthographic standard (for the ejective /k'/ behind the corpus's *q*; §9.9, §2.3). Briceño Chel, F., & Can Tec, G. R. (Coords.). (2014). *U nu'ukbesajil u ts'íibta'al maayat'aan / Normas de escritura para la lengua maya*. Instituto Nacional de Lenguas Indígenas (INALI). https://site.inali.gob.mx/pdf/norma_maya.pdf, the standard writes the glottalized stops *k', ts', ch', p', t'* (there is no *q* in Maya), confirming /k'/ as a distinct phoneme and so underwriting the reading of the corpus's stylised *q* (*qexcan* ← *k'ex*; *qux* ← *k'ux*) as a real ejective.

36. Modern Spanish→Maya wordlist (peninsular Yucatec, INALI-style orthography), a present-day source independent of Cordemex, corroborating several §9.9 roots. *Diccionario Maya* (Spanish→Maya), distributed via ilide.info / Scribd ( https://www.scribd.com/document/36429175/Diccionario-Maya); copy added to the project. Confirms **tsúuk** (listed in *múuch' tsúuk* for *montón* "heap") for the *Otsuks* root; **k'uux** "morder; odiar; rencor" for *quxzeh*; **taal** "venir" for *a'tul*; **ba'ax** "qué; cosa" for *buxa / Axba*; and **ka** "que" for the §9.9 particle *ka*. The Yucatec watch/sentinel field weighed against *cheyel*, *ch'úuk* "lie in wait, ambush," *cha'an* "behold, watch," *pa'at* "wait," *kanan* "guard", is also drawn from this source.

37. Text 5, Line 1 (the Kamasan Smith). In-game footage capture of the Vaal **Kamasan Smith** (NPC *Xomatl*), a fire/forge-themed boss in **Atziri's Temple at Lira Vaal**, encountered at the height of Vaal power before the Cataclysm; he works the forge until the player enters, then speaks *Ti ek tala jare'yantul!* and attacks. Line tokens corroborated by Cordemex[7] (*ti'*, *ek'*, *taal*, *yan*, *tul*) and the modern wordlist[36] (*estrella* = *eek'*; *venir* = *taal*); *jare'* per [17].

38. *Guatelitzi, Architect of Flesh.* Path of Exile Wiki. https://www.poewiki.net/wiki/Guatelitzi,_Architect_of_Flesh, a Vaal Architect of the **Temple of Atzoatl** (Incursion, v3.3.0; core v3.5.0); resident of *Pools of Restoration / Sanctum of Vitality / Sanctum of Immortality* (room flavour *"Flesh rending for life unending"*), with maximum-Life, Energy-Shield, and Life/ES-regeneration signature modifiers; the flesh-and-immortality architect named by Zelina's *"Tome of Guatelitzi"* (§9.8). In-game identification contributed by Reddit user *Tenebris-Umbra*.

39. *Xibaqua.* Path of Exile Wiki. https://www.poewiki.net/wiki/Xibaqua, the progenitor of all Vaal, "born from the flesh of ancient Vaal gods"; origin myth quoted from the *Demon Stitcher* item (*History of Wraeclast*, https://www.poewiki.net/wiki/History_of_Wraeclast): the gods reclaim their flesh until "a droplet of pure light: The first Vaal" remains.

40. Temple of Atzoatl lore. Path of Exile Wiki, *The Vaal* and *Atziri (lore)*. https://www.poewiki.net/wiki/The_Vaal, https://www.poewiki.net/wiki/Atziri_(lore), the temple's pursuits (immortality, corruption, weather, sacrifice), Atziri's later seat, the "Demon of Atzoatl."

41. Vaal gods (*Yaomac, Yugul, Ralakesh*). Path of Exile Wiki, *The Vaal* and *History of Wraeclast*. https://www.poewiki.net/wiki/The_Vaal, https://www.poewiki.net/wiki/History_of_Wraeclast, *Yaomac* (three serpentine heads, shepherd of Vaal souls; *Yaomac's Accord*, *Triumvirate Authority*), *Yugul* ("Reflection of Terror," Act 8 pantheon), *Ralakesh* ("Master of a Million Faces").

42. *Kopec* and *Kamasa* (Vaal gods). Path of Exile Wiki, *God*; and the Chaos-Bloodline ascendancies *Priest of Kopec / Priest of Kamasa / Priest of Yaomac*. https://www.poewiki.net/wiki/God, https://www.poewiki.net/wiki/Priest_of_Kopec

43. Vaal Architects of the Temple of Atzoatl (the architect roster). Path of Exile Wiki, *Incursion room*. https://www.poewiki.net/wiki/Incursion_room

44. Text 5, Lines 2 and 3 (*Ahuatotli, the Blind*; *Mektul*). In-game footage captures of two Vaal bosses' combat shouts (*Ahuatotli* is the Delve boss "Ahuatotli, the Blind"). Recognisable tokens corroborated by Cordemex[7] and the modern wordlist[36]: *táak'in* "gold," *k'áak'* "fire," *ik'* "wind / spirit."

45. Comparative onomastics for the pantheon names (the cross-check pass behind §11.3). *Camazotz*, the Popol Vuh death-bat (K'iche' *kame* "death" + *sotz'* "bat"): https://en.wikipedia.org/wiki/Camazotz . *Apep / Apophis*, Egyptian chaos-serpent: https://en.wikipedia.org/wiki/Apep . *Rakshasa*, the shape-shifting demons of Hindu / Buddhist lore: https://en.wikipedia.org/wiki/Rakshasa . *Arachne* (Greek): https://en.wikipedia.org/wiki/Arachne ; *Kali* (Hindu): https://en.wikipedia.org/wiki/Kali . The Nahuatl locative *-mac* "in the hands of" (from *māitl* "hand") and *calli* "house" per [10]. These foreign roots are recorded as onomastic comparison, not as additions to the committed Maya / Nahuatl palette.

46. *Nahuatl 1100* (vocabulary course). My Little Word Land. https://mylittlewordland.com/course/304181/nahuatl-1100 . A community-built Nahuatl word-list, used here as a cross-reference pool. It glosses *atzoatl* as "dirty water" (§11.2). Treated as an **informal primary source requiring secondary validation**: the gloss is borne out by *tzoatl* "dirty water, slops" (lauazas o lauaduras, Molina 1571) in the Wired Humanities Nahuatl Dictionary[10], https://nahuatl.wired-humanities.org/content/tzoatl . Other entries from this list are to be confirmed against a primary dictionary before any adoption.

47. Christenson, A. J. (n.d.). *K'iche'-English Dictionary and Guide to Pronunciation of the K'iche'-Maya Alphabet*. Brigham Young University; offered to FAMSI as a research tool. https://www.famsi.org/mayawriting/dictionary/christenson/quidic_complete.pdf . Compiled from field work with native K'iche' speakers in Momostenango and Totonicapán, 1978-1985. The project's first dedicated K'iche' dictionary; the lexical authority for the Highland-Maya seam (*jare*, *koriek*), where the Wikipedia phonology note[17] previously stood alone.

48. *Vaal Architect lore, and some connections I found while studying it.* Community lore compilation by Reddit user *Tenebris-Umbra*, r/Wraeclast. https://www.reddit.com/r/Wraeclast/comments/1shprfn/vaal_architect_lore_and_some_connections_i_found/ . Used here only for its consolidation of in-game, wiki-attested architect roles (room functions, boss identities, and flavour text); the author's speculative connections are not adopted. Primary roster authority remains the *Incursion room* page[43].
